
/* Shared center-line positions for deck quantity calculation and preview. */
(function(root){
  'use strict';
  function joists(length,spacing,fixed=true){
    const total=Math.round(Number(length)*10),gap=Math.round(Number(spacing)*10);
    if(!Number.isSafeInteger(total)||total<=0||!Number.isSafeInteger(gap)||gap<=0)throw Error('시공길이와 장선 간격은 0.1mm 이상으로 입력해주세요.');
    const segments=Math.ceil(total/gap);
    if(segments+1>2000)throw Error('장선 수량은 2,000줄 이하로 계산해주세요.');
    const positions=Array.from({length:segments},(_,i)=>(fixed?i*gap:Math.round(i*total/segments))/10);
    positions.push(total/10);return positions;
  }
  function frame(length,spacing,fixed,boardPieces,width=50){
    const total=Math.round(Number(length)*10),section=Math.round(Number(width)*10),pieces=boardPieces.map(p=>Math.round(Number(p)*10));
    if(!pieces.length||pieces.some(p=>!Number.isSafeInteger(p)||p<=0)||pieces.reduce((a,b)=>a+b,0)!==total)throw Error('상판 이음부 치수를 확인해주세요.');
    const seams=[];let offset=0;for(const p of pieces.slice(0,-1)){offset+=p;seams.push(offset);}
    if(!Number.isSafeInteger(section)||section<=0||section%2)throw Error('이중 장선 각관 폭을 확인해주세요.');
    if(seams.length&&Math.round(Number(spacing)*10)<section)throw Error('이중 장선을 포함한 장선 간격은 각관 폭 50mm 이상으로 입력해주세요.');
    const all=new Set(),doubles=new Set(),segments=[];let start=0;
    function segment(end){
      if(end<start)throw Error('상판 이음부의 이중 장선이 겹칩니다. 상판 길이를 확인해주세요.');
      if(end===start){all.add(start);return;}
      const positions=joists((end-start)/10,spacing,fixed).map(p=>Math.round(p*10)+start);
      for(const p of positions){all.add(p);if(all.size>2000)throw Error('이중 장선을 포함한 장선 수량은 2,000줄 이하로 계산해주세요.');}
      segments.push({start:start/10,end:end/10,positions:positions.map(p=>p/10)});
    }
    for(const seam of seams){
      const left=seam-section/2,right=seam+section/2;
      if(left<0||right>total)throw Error('상판 이음부가 끝단에 너무 가깝습니다. 50mm 이중 장선을 확보할 수 있도록 상판 길이를 확인해주세요.');
      if(doubles.has(left))throw Error('상판 이음부의 이중 장선이 겹칩니다. 상판 길이를 확인해주세요.');
      segment(left);doubles.add(left);doubles.add(right);start=right;
    }
    segment(total);
    if(!segments.length)throw Error('시공길이가 너무 짧습니다. 이중 장선 외 일반 장선 배치 구간을 확보해주세요.');
    const positions=[...all].sort((a,b)=>a-b).map(p=>p/10),doublePositions=[...doubles].sort((a,b)=>a-b).map(p=>p/10);
    return{positions,doublePositions,seams:seams.map(p=>p/10),segments,regularCount:positions.length-doublePositions.length,doubleCount:doublePositions.length,width:section/10};
  }
  function frameRows(length,spacing,fixed,rows,width=50){
    const total=Math.round(Number(length)*10),seams=new Set();
    for(const parts of rows){let offset=0;if(parts.reduce((n,p)=>n+Math.round(p*10),0)!==total)throw Error('행별 상판 길이가 시공 길이와 다릅니다.');for(const part of parts.slice(0,-1)){offset+=Math.round(part*10);seams.add(offset);}}
    const edges=[0,...seams,total].sort((a,b)=>a-b),pieces=edges.slice(1).map((p,i)=>(p-edges[i])/10);
    return frame(length,spacing,fixed,pieces,width);
  }
  const api={joists,frame,frameRows};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.DeckLayout=api;
})(typeof window==='undefined'?globalThis:window);

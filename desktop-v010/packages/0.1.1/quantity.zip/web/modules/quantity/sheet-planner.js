
(() => {
  'use strict';
  const q=id=>document.getElementById(id),E=window.SheetEngine,R=window.StockReport;
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>Number(n).toLocaleString('ko-KR',{maximumFractionDigits:1}),sqm=n=>(n/1e6).toFixed(3);
  const materials=['합판','MDF','철판','기타 판재'];
  function row(stock,data={},editor=false){
    const r=document.createElement('div');if(data.catalog)r.dataset.catalog=JSON.stringify(data.catalog);r.className='sheet-input-row'+(stock?'':' sheet-item-row');
    const select=document.createElement('select');select.className='sheet-material';select.setAttribute('aria-label','판재 종류');
    (materials.includes(data.material)?materials:materials.concat(data.material||[])).forEach(m=>select.add(new Option(m,m)));select.value=data.material||materials[0];r.appendChild(select);
    for(const [field,label] of [['length','길이 mm'],['width','폭 mm'],...stock?[]:[['quantity','수량']]]){
      const input=document.createElement('input');input.type='number';input.className='sheet-'+field;input.min=field==='quantity'?'1':'0.1';input.step=field==='quantity'?'1':'0.1';input.inputMode=field==='quantity'?'numeric':'decimal';input.placeholder=label;input.setAttribute('aria-label',label);input.value=data[field]??'';r.appendChild(input);
    }
    const remove=document.createElement('button');remove.type='button';remove.className='cut-remove';remove.textContent='×';remove.setAttribute('aria-label',stock?'면 원자재 행 삭제':'면 재단 품목 행 삭제');remove.onclick=()=>r.remove();r.appendChild(remove);q(stock?'sheetStockRows':'sheetItemRows').appendChild(r);if(!editor)window.MaterialLists.compact(r);return r;
  }
  window.MaterialLists.bind('sheetStockRows','sheetAddStock',(data,editor)=>row(true,data,editor));
  window.MaterialLists.bind('sheetItemRows','sheetAddItem',(data,editor)=>row(false,data,editor));
  const collect=id=>[...q(id).children].map(r=>({catalog:JSON.parse(r.dataset.catalog||'null'),material:r.querySelector('.sheet-material').value,length:r.querySelector('.sheet-length').value,width:r.querySelector('.sheet-width').value,...r.querySelector('.sheet-quantity')?{quantity:r.querySelector('.sheet-quantity').value}:{}}));
  window.currentSheetData=()=>({stocks:collect('sheetStockRows'),items:collect('sheetItemRows'),kerf:q('sheetKerf').value,rotate:q('sheetRotate').checked,marginPercent:q('sheetMarginPercent').value});
  window.clearSheetResults=(value='—')=>{window.MarginAllowance?.clear('sheet');['sheetCount','sheetPieceCount'].forEach(id=>q(id).textContent=value);R.displayUtilization(q('sheetUsage'),value);q('sheetStockSummary').innerHTML='';q('sheetTable').innerHTML=q('sheetDiagrams').innerHTML=q('sheetDetails').textContent='';q('sheetMaterialLegend').innerHTML=q('sheetMaterialQuantities').innerHTML='';};
  window.applySheetData=data=>{window.MaterialLists.reset('sheetStockRows');window.MaterialLists.reset('sheetItemRows');q('sheetStockRows').replaceChildren();q('sheetItemRows').replaceChildren();(data.stocks||[]).forEach(x=>row(true,x));(data.items||[]).forEach(x=>row(false,x));q('sheetKerf').value=data.kerf??'';q('sheetMarginPercent').value=data.marginPercent??'0';q('sheetRotate').checked=data.rotate!==false;window.clearSheetResults();};
  function error(message){window.clearSheetResults();q('sheetTable').innerHTML='<div class="note" role="alert">'+esc(message)+'</div>';}
  function drawing(b,material){
    let s='<svg data-stock-code="'+material.code+'" viewBox="0 0 '+b.length+' '+b.width+'" role="img" aria-label="'+esc(b.material)+' '+fmt(b.length)+' × '+fmt(b.width)+'mm 재단 배치"><rect width="'+b.length+'" height="'+b.width+'" fill="#e49b91"/>';
    b.free.forEach(r=>{s+='<rect x="'+r.x+'" y="'+r.y+'" width="'+r.w+'" height="'+r.h+'" fill="#e2e7e3"><title>잔여 '+fmt(r.w)+' × '+fmt(r.h)+'mm</title></rect>';});
    b.parts.forEach((p,i)=>{const color=material.color,label=fmt(p.originalLength)+' × '+fmt(p.originalWidth),font=Math.min(b.length/32,b.width/16,Math.min(p.w,p.h)/4,p.w/(label.length*.65));s+='<g><rect class="sheet-cut-piece" data-stock-code="'+material.code+'" x="'+p.x+'" y="'+p.y+'" width="'+p.w+'" height="'+p.h+'" fill="'+color+'" stroke="#ffffff" stroke-width="1" vector-effect="non-scaling-stroke"><title>'+label+'mm'+(p.rotated?' · 90도 회전':'')+'</title></rect><text x="'+(p.x+p.w/2)+'" y="'+(p.y+p.h/2)+'" text-anchor="middle" dominant-baseline="middle" fill="#fff" font-size="'+font+'">'+label+(p.rotated?' ↻':'')+'</text></g>';});
    return s+'</svg>';
  }
  function composition(b){const counts=new Map();b.parts.forEach(p=>{const key=fmt(p.originalLength)+' × '+fmt(p.originalWidth)+'mm';counts.set(key,(counts.get(key)||0)+1);});return [...counts].map(([size,n])=>size+' × '+n+'개').join(' + ');}
  q('sheetCalculate').onclick=()=>{
    try{
      const data=window.currentSheetData(),k=Number(data.kerf);if(!Number.isFinite(k)||k<0)throw Error('톱날 두께를 확인해주세요.');
      if(!data.stocks.length||!data.items.length)throw Error('원자재와 재단 품목을 추가해주세요.');
      const grouped=new Map();data.items.forEach(item=>{if(!grouped.has(item.material))grouped.set(item.material,[]);grouped.get(item.material).push(item);});
      const plans=[...grouped].map(([material,items])=>{const options=data.stocks.filter(s=>s.material===material);if(!options.length)throw Error(material+' 원자재 규격을 추가해주세요.');const result=E.optimize(options,items,k,data.rotate);return {...result,bins:result.bins.map(b=>({...b,material}))};});
      const bins=plans.flatMap(p=>p.bins),groups=E.groups(bins),total=plans.reduce((s,p)=>s+p.totalArea,0),net=plans.reduce((s,p)=>s+p.netArea,0),waste=plans.reduce((s,p)=>s+p.wasteArea,0),loss=plans.reduce((s,p)=>s+p.lossArea,0);
      const report=R.create(data.stocks,bins,'sheet'),source=b=>report.lookup(b.material,b.length,b.width);
      q('sheetStockSummary').innerHTML=R.summary(report);q('sheetMaterialLegend').innerHTML=R.legend(report);q('sheetMaterialQuantities').innerHTML=R.table(report);
      q('sheetCount').textContent=bins.length;q('sheetPieceCount').textContent=plans.reduce((s,p)=>s+p.pieceCount,0);R.displayUtilization(q('sheetUsage'),R.utilization(net,total));
      q('sheetDetails').textContent='원자재 '+sqm(total)+'㎡ · 재단품 '+sqm(net)+'㎡ · 잔여 '+sqm(waste)+'㎡ · 톱날 손실 '+sqm(loss)+'㎡';
      q('sheetTable').innerHTML='<div class="note">여러 순서와 절단 방향을 비교한 배치입니다. 원자재 면적을 우선 줄이고, 같으면 장수가 적은 배치를 선택합니다. 전체 조합의 절대 최솟값을 보장하지는 않습니다. 같은 자재명은 동일 재질·두께 기준으로 입력해주세요.</div><table class="cut-table"><thead><tr><th>자재</th><th>선택 원자재 · 길이 × 폭</th><th>재단 구성</th><th>수량</th><th>잔여/장</th></tr></thead><tbody>'+groups.map(b=>'<tr data-stock-code="'+source(b).code+'"><td>'+R.swatch(source(b))+' '+source(b).code+' · '+esc(b.material)+'</td><td>'+fmt(b.length)+' × '+fmt(b.width)+'mm</td><td>'+composition(b)+'</td><td>'+b.quantity+'장</td><td>'+sqm(b.waste)+'㎡</td></tr>').join('')+'</tbody></table>';
      q('sheetDiagrams').innerHTML=groups.map(b=>{const material=source(b);return '<div class="diagram-group sheet-diagram" data-stock-code="'+material.code+'"><div class="section-head"><h3>'+R.swatch(material)+' '+material.code+' · '+esc(b.material)+' · '+fmt(b.length)+' × '+fmt(b.width)+'mm</h3><span class="pill">동일 배치 × '+b.quantity+'장</span></div>'+drawing(b,material)+'<div class="sheet-legend"><span>규격별 색상: 재단품</span><span>회색: 잔여</span><span>연분홍: 톱날 손실</span><span>↻: 90도 회전</span></div><div class="site-status">'+composition(b)+' · 톱날 '+fmt(k)+'mm · 잔여 '+sqm(b.waste)+'㎡/장</div></div>';}).join('');
    }catch(e){error(e.message);}
  };
  q('sheetPrint').onclick=window.printReport;
  q('sheetSaveSite').onclick=()=>{q('siteName').value=q('sheetSiteName').value;q('saveSite').click();};
  q('sheetLoadSite').onclick=()=>{q('siteList').value=q('sheetSiteList').value;q('loadSite').click();};
  q('sheetSiteAdd').onclick=()=>{q('sheetSiteName').value='';q('sheetSiteList').value='';q('sheetSiteName').focus();q('sheetSaveStatus').textContent='새 현장명을 입력하고 저장해주세요.';};
  q('sheetSiteDelete').onclick=()=>{q('siteList').value=q('sheetSiteList').value;q('siteName').value=q('sheetSiteName').value;q('siteNameDelete').click();};
  window.clearSheetResults();try{window.refreshPlannerSites();}catch(e){q('sheetSaveStatus').textContent=e.message;}
})();

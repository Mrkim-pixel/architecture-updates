
/* Stock-aware steel demand used by both layout comparison and the final report. */
(function(root){
 'use strict';
 function calculate(input,quick=false){
  const E=typeof module!=='undefined'&&module.exports?require('./cutting-engine'):root.CuttingEngine;
  const S=typeof module!=='undefined'&&module.exports?require('./steel-reuse'):root.SteelReuse;
  const {length,width,joists,bearers,postLength,postCount,options,kerf,splice,minimum}=input,needs=[];
  if(!Number.isFinite(postLength)||postLength<0)throw Error('기둥 재단 높이는 0 이상으로 입력해주세요.');
  if(!Number.isFinite(minimum)||minimum<0)throw Error('잔재 최소 사용 가능 길이는 0 이상으로 입력해주세요.');
  if(!splice&&postLength>Math.max(...options))throw Error('기둥 '+postLength.toLocaleString('ko-KR')+'mm는 각관 원자재 길이를 초과합니다. 이어쓰기를 체크하거나 원자재 길이를 추가해주세요.');
  function prepare(role,run,quantity){
   const parts=quantity?E.runPieces(run,options,kerf):[],demand=[],queues=new Map();
   for(let i=0;i<quantity;i++){const id=role+'-'+(i+1);needs.push({id,role,length:run});for(const piece of parts){demand.push(piece);if(!queues.has(piece))queues.set(piece,[]);queues.get(piece).push(id);}}
   const plan=(quick?E.packQuick:E.pack)(options,demand,kerf);
   for(const bin of plan.bins){bin.owner=role;bin.roles=bin.used.map(()=>role);bin.jobIds=bin.used.map(n=>queues.get(n).shift());}
   return plan;
  }
  const jp=prepare('joist',width,joists),bp=prepare('bearer',length,bearers),pp=prepare('post',postLength,postCount),plans=[jp,bp,pp];
  let recycling={assemblies:[],recoveredLength:0,reusedSegments:0,jointCount:0,savedCount:0,savedLength:0,limited:false};
  if(quick){
   const demand=plans.flatMap(plan=>plan.bins.flatMap(bin=>bin.used));
   const pooled=demand.length<=2000?E.packQuick(options,demand,kerf):{total:plans.reduce((n,p)=>n+p.total,0),bins:plans.flatMap(p=>p.bins)};
   return{total:pooled.total,quantity:pooled.bins.length};
  }
  let combined;
  if(splice){recycling=S.fromNeeds(plans.flatMap(plan=>plan.bins),needs,kerf,minimum,options);combined=recycling;}
  else combined=E.packShared(options,plans.flatMap(plan=>plan.bins),kerf);
  for(const [plan,owner]of [[jp,'joist'],[bp,'bearer'],[pp,'post']]){
   plan.bins=combined.bins.filter(bin=>bin.owner===owner);plan.total=plan.bins.reduce((n,b)=>n+b.stock,0);plan.waste=plan.bins.reduce((n,b)=>n+b.left,0);plan.loss=plan.bins.reduce((n,b)=>n+b.loss,0);if(!splice)plan.exact=combined.exact;
  }
  return{jp,bp,pp,recycling,total:plans.reduce((n,p)=>n+p.total,0),quantity:plans.reduce((n,p)=>n+p.bins.length,0)};
 }
 const api={calculate};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.FrameStock=api;
})(typeof window==='undefined'?globalThis:window);


/* One reusable input form per list; committed rows are compact text, not repeated forms. */
(() => {
 'use strict';
 const bindings=new Map(),q=id=>document.getElementById(id),controls=row=>[...row.querySelectorAll('input,select')];
 const formatter=new Intl.NumberFormat('ko-KR',{maximumFractionDigits:1}),fmt=value=>formatter.format(Number(value));
 function reset(binding){binding.status.textContent='';for(const input of controls(binding.editor))if(input.type==='number')input.value='';}
 function summary(row){
  const values=controls(row),kind=values.find(el=>el.tagName==='SELECT'||el.type==='text')?.value||'자재';
  const dimensions=values.filter(el=>el.type==='number'&&!el.classList.contains('cut-quantity')&&!el.classList.contains('sheet-quantity'));
  const quantity=values.find(el=>el.classList.contains('cut-quantity')||el.classList.contains('sheet-quantity'));
  return {kind,measure:dimensions.map(el=>Number(el.value)>0?fmt(el.value):'미입력').join(' × ')+'mm',quantity:quantity?' × '+(Number(quantity.value)>0?fmt(quantity.value):'미입력')+'개':null};
 }
 function compact(row){
  const list=row.parentElement,binding=bindings.get(list?.id);if(!binding)return;
  if(row.classList.contains('text-material-row')){paint(row);return;}
  const values=document.createElement('div');values.className='compact-values';values.hidden=true;
  for(const input of controls(row))values.appendChild(input);
  const remove=row.querySelector('.cut-remove');
  const text=document.createElement('span');text.className='material-row-text';
  const actions=document.createElement('span');actions.className='material-row-actions';
  actions.append(remove);row.replaceChildren(values,text,actions);row.classList.add('text-material-row');paint(row);
 }
 function paint(row){
  const text=row.querySelector('.material-row-text'),parts=summary(row);
  const name=document.createElement('span');name.className='material-name';name.textContent=parts.kind;name.title=parts.kind;
  const measure=document.createElement('span');measure.className='material-measure';measure.textContent=parts.measure;
  text.replaceChildren(name,measure);
  if(parts.quantity!==null){const qty=document.createElement('span');qty.className='material-quantity';qty.textContent=parts.quantity;text.appendChild(qty);}
 }
 function bind(listId,buttonId,create){
  const list=q(listId),button=q(buttonId),editor=create({},true);editor.remove();editor.id=listId+'Entry';editor.classList.add('material-entry');editor.querySelector('.cut-remove').remove();
  const status=document.createElement('div');status.className='material-entry-status site-status';status.setAttribute('role','status');
  const binding={editor,status,create};bindings.set(listId,binding);
  list.classList.add('committed-material-list');list.before(editor,button,status);
  button.onclick=()=>{
   const data={};
   for(const input of controls(editor)){
    const key=input.className.replace(/^(stock|cut|sheet|louver-stock)-/,'').replace(/^material$/,'material');
    const value=input.value.trim();
    const number=Number(value),invalidNumber=input.type==='number'&&(!Number.isFinite(number)||number<0.1||(key==='quantity'&&(!Number.isInteger(number)||number>2000)));
    if(!value||invalidNumber){
     status.textContent=(input.getAttribute('aria-label')||input.placeholder||'입력값')+'을 확인해주세요.';input.focus();return;
    }
    data[key]=value;
   }
   create(data,false);
   reset(binding);status.textContent='목록에 반영했습니다. 계산 버튼을 눌러주세요.';editor.querySelector('input')?.focus();
  };
 }
 const deckLists=[];
 function mountDeck(){
  if(deckLists.length)return;
  for(const [id,kind]of [['boardOptions','데크 상판'],['steelOptions','각관']]){
   const backing=q(id),list=document.createElement('div'),button=document.createElement('button');
   backing.type='hidden';list.id=id+'Rows';list.className='cut-input-rows';button.type='button';button.id=id+'Add';button.className='add-row';button.textContent='＋ 원자재 추가';backing.after(list,button);
   function sync(){backing.value=[...list.children].map(row=>row.querySelector('.stock-length').value).join(', ');}
   function create(data={},editor=false){
    const row=document.createElement('div');row.className='deck-stock-row';
    const material=document.createElement('input');material.type='text';material.className='stock-material';material.value=kind;material.hidden=true;
    const length=document.createElement('input');length.type='number';length.className='stock-length';length.min='0.1';length.step='0.1';length.inputMode='decimal';length.placeholder='원자재 길이 mm';length.setAttribute('aria-label',kind+' 원자재 길이 mm');length.value=data.length??'';
    const remove=document.createElement('button');remove.type='button';remove.className='cut-remove';remove.textContent='×';remove.setAttribute('aria-label',kind+' 원자재 삭제');remove.onclick=()=>{row.remove();sync();};
    row.append(material,length,remove);
    if(editor){list.appendChild(row);return row;}
    if([...list.children].some(item=>Number(item.querySelector('.stock-length').value)===Number(length.value)))return row;
    list.appendChild(row);compact(row);sync();return row;
   }
   bind(list.id,button.id,create);
   deckLists.push({backing,list,create});
  }
  refreshDeck();
 }
 function refreshDeck(){for(const {backing,list,create}of deckLists){const saved=backing.value;list.replaceChildren();reset(bindings.get(list.id));for(const length of saved.split(',').map(s=>s.trim()).filter(s=>Number.isFinite(Number(s))&&Number(s)>0))create({length});if(!list.children.length)backing.value='';}}
 window.MaterialLists={add:(id,data)=>{const row=bindings.get(id).create(data,false);if(row.parentElement)row.dataset.catalog=JSON.stringify(data.catalog||null);return row;},bind,compact,mountDeck,refreshDeck,reset:id=>{const binding=bindings.get(id);if(binding)reset(binding);}};
})();

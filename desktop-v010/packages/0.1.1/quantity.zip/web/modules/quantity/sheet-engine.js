
/* Guillotine sheet nesting: integer tenths of a millimetre, multiple stock sizes. */
(function(root){
  'use strict';
  const unit=n=>Math.round(Number(n)*10),area=r=>r.w*r.h;
  function optimize(rawStock,rawItems,kerf=0,allowRotate=true){
    const k=unit(kerf);
    if(!Number.isSafeInteger(k)||!Number.isFinite(Number(kerf))||Number(kerf)<0)throw Error('톱날 두께를 확인해주세요.');
    function size(o){const w=unit(o.length),h=unit(o.width);if(!Number.isSafeInteger(w)||!Number.isSafeInteger(h)||w<=0||h<=0||w>1000000||h>1000000)throw Error('길이와 폭은 0.1~100,000mm로 입력해주세요.');return{w,h};}
    const stockMap=new Map();rawStock.forEach(o=>{const s=size(o);stockMap.set(s.w+','+s.h,s);});
    const stocks=[...stockMap.values()].sort((a,b)=>area(a)-area(b));
    if(!stocks.length||stocks.length>20)throw Error('원자재 규격을 1~20개 입력해주세요.');
    const pieces=[];
    rawItems.forEach((o,i)=>{const s=size(o),qty=Number(o.quantity);if(!Number.isInteger(qty)||qty<1||pieces.length+qty>300)throw Error('재단 수량은 자재별 총 300개 이하로 입력해주세요.');for(let n=0;n<qty;n++)pieces.push({...s,id:i,number:pieces.length+1});});
    if(!pieces.length)throw Error('재단 품목을 추가해주세요.');
    const fits=(w,h,r)=>w<=r.w&&h<=r.h&&(w===r.w||w+k<=r.w)&&(h===r.h||h+k<=r.h);
    for(const p of pieces)if(!stocks.some(s=>fits(p.w,p.h,s)||(allowRotate&&fits(p.h,p.w,s))))throw Error((p.w/10)+' × '+(p.h/10)+'mm 품목이 원자재에 들어가지 않습니다. 치수·회전·톱날 두께를 확인해주세요.');
    let work=0;
    function position(bin,p){
      let best=null;
      for(let i=0;i<bin.free.length;i++){
        const r=bin.free[i];
        for(const rotated of allowRotate&&p.w!==p.h?[false,true]:[false]){
          work++;
          const w=rotated?p.h:p.w,h=rotated?p.w:p.h;
          if(!fits(w,h,r))continue;
          const score=[Math.min(r.w-w,r.h-h),area(r)-w*h,Math.max(r.w-w,r.h-h)];
          if(!best||compare(score,best.score)<0)best={i,w,h,rotated,score};
        }
      }
      return best;
    }
    function place(bin,p,pos,vertical){
      const r=bin.free.splice(pos.i,1)[0],w=pos.w,h=pos.h,dw=r.w-w,dh=r.h-h,gx=dw?k:0,gy=dh?k:0;
      if(vertical==='adaptive')vertical=Math.max((dw-gx)*r.h,w*(dh-gy))>=Math.max(r.w*(dh-gy),(dw-gx)*h);
      const add=(x,y,w,h)=>{if(w>0&&h>0)bin.free.push({x,y,w,h});};
      if(vertical){add(r.x+w+gx,r.y,dw-gx,r.h);add(r.x,r.y+h+gy,w,dh-gy);}
      else{add(r.x,r.y+h+gy,r.w,dh-gy);add(r.x+w+gx,r.y,dw-gx,h);}
      bin.parts.push({x:r.x,y:r.y,w,h,rotated:pos.rotated,id:p.id,number:p.number,originalLength:p.w,originalWidth:p.h});
    }
    function trial(order,vertical){
      let remaining=order.slice();const bins=[];
      while(remaining.length){
        let candidate=null;
        for(const stock of stocks){
          const bin={...stock,free:[{x:0,y:0,...stock}],parts:[]},taken=[];
          for(let i=0;i<remaining.length;i++){const pos=position(bin,remaining[i]);if(pos){place(bin,remaining[i],pos,vertical);taken.push(i);}}
          if(!taken.length)continue;
          const net=bin.parts.reduce((s,p)=>s+area(p),0),score=[-net/area(stock),area(stock)-net,-net,area(stock),-taken.length];
          if(!candidate||compare(score,candidate.score)<0)candidate={bin,taken:new Set(taken),score};
        }
        if(!candidate)throw Error('배치할 수 없는 재단 품목이 있습니다.');
        bins.push(candidate.bin);remaining=remaining.filter((_,i)=>!candidate.taken.has(i));
      }
      return bins;
    }
    const strategies=[(a,b)=>area(b)-area(a),(a,b)=>Math.max(b.w,b.h)-Math.max(a.w,a.h),(a,b)=>b.w-a.w,(a,b)=>b.h-a.h];
    let best=null,bestScore=null,trials=0;const seenOrders=new Set();
    // Preserve existing candidates before spending the remaining budget on a
    // split that keeps the largest reusable rectangle after every placement.
    const attempts=strategies.flatMap(sort=>[true,false].map(vertical=>({sort,vertical})));
    attempts.push(...strategies.map(sort=>({sort,vertical:'adaptive'})));
    for(const {sort,vertical} of attempts){
      if(trials&&work>1500000)continue;
      const order=pieces.slice().sort(sort),key=vertical+':'+order.map(p=>p.number).join(',');
      if(seenOrders.has(key))continue;seenOrders.add(key);
      const bins=trial(order,vertical),score=[bins.reduce((s,b)=>s+area(b),0),bins.length];trials++;
      if(!best||compare(score,bestScore)<0){best=bins;bestScore=score;}
    }
    const bins=best.map(b=>{
      const net=b.parts.reduce((s,p)=>s+area(p),0),left=b.free.reduce((s,r)=>s+area(r),0);
      const rect=r=>({...r,x:r.x/10,y:r.y/10,w:r.w/10,h:r.h/10});
      return {length:b.w/10,width:b.h/10,parts:b.parts.map(p=>({...rect(p),originalLength:p.originalLength/10,originalWidth:p.originalWidth/10})),free:b.free.map(rect),net:net/100,waste:left/100,loss:(area(b)-net-left)/100};
    });
    return {bins,trials,totalArea:bestScore[0]/100,netArea:bins.reduce((s,b)=>s+b.net,0),wasteArea:bins.reduce((s,b)=>s+b.waste,0),lossArea:bins.reduce((s,b)=>s+b.loss,0),pieceCount:pieces.length};
  }
  function compare(a,b){for(let i=0;i<a.length;i++){if(a[i]<b[i])return -1;if(a[i]>b[i])return 1;}return 0;}
  function groups(bins){const map=new Map();bins.forEach(b=>{const key=JSON.stringify([b.material,b.length,b.width,b.parts.map(p=>[p.x,p.y,p.w,p.h,p.originalLength,p.originalWidth,p.rotated]).sort((a,b)=>compare(a,b))]);if(!map.has(key))map.set(key,{...b,quantity:0});map.get(key).quantity++;});return [...map.values()];}
  const api={optimize,groups};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.SheetEngine=api;
})(typeof window==='undefined'?globalThis:window);

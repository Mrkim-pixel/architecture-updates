
/* Shared installation rows. Integer tenths prevent seams drifting between drawings and cuts. */
(function(root){
 'use strict';
 const units=n=>Math.round(Number(n)*10),mm=n=>n/10;
 function manual(total,settings={}){
  const run=units(total),raw=String(settings.lengths??'').trim(),countText=String(settings.count??'').trim();
  if(!Number.isSafeInteger(run)||run<1)throw Error('시공 방향 길이를 확인해주세요.');
  if(!raw&&!countText)return null;
  const count=countText?Number(countText):null;
  if(count!==null&&(!Number.isInteger(count)||count<1||count>2000))throw Error('분할 개수는 1~2,000개 정수로 입력해주세요.');
  let parts;
  if(raw){
   const tokens=raw.split(/[,;\s]+/);
   if(tokens.length>2000||tokens.some(t=>!/^\d+(?:\.\d)?$/.test(t)||units(t)<1||!Number.isSafeInteger(units(t))))throw Error('구간 치수는 0.1mm 이상, 소수 첫째 자리까지 쉼표로 입력해주세요.');
   parts=tokens.map(units);
   if(parts.length===1){
    const size=parts[0],n=count??Math.ceil(run/size),last=run-(n-1)*size;
    if(n>2000||last<1||last>size)throw Error('분할 개수와 기준 길이가 시공 방향 길이에 맞지 않습니다. 마지막 구간이 0보다 크고 기준 길이 이하여야 합니다.');
    parts=Array(n-1).fill(size).concat(last);
   }else if(count!==null&&count!==parts.length)throw Error('분할 개수와 입력한 구간 치수 개수가 다릅니다.');
   if(parts.reduce((a,b)=>a+b,0)!==run)throw Error('구간 치수 합계가 시공 방향 길이 '+total+'mm와 같아야 합니다.');
  }else{
   if(count>run)throw Error('분할한 각 구간은 0.1mm 이상이어야 합니다.');
   parts=Array.from({length:count},(_,i)=>Math.round((i+1)*run/count)-Math.round(i*run/count));
  }
  return parts.map(mm);
 }
 function seams(parts){let n=0;return parts.slice(0,-1).map(p=>{n+=units(p);return n;});}
 function optimize(total,options,rowCount,settings={},kerf=0,validate=null,evaluate=null){
  const packer=typeof module!=='undefined'&&module.exports?require('./cutting-engine'):root.CuttingEngine;
  const run=units(total),raw=String(settings.lengths??'').trim(),requested=String(settings.count??'').trim(),cuts=new Map(),maximum=Math.max(...options.map(units));
  if(requested)manual(total,{count:requested}); // Validate the count before generating candidates.
  const add=parts=>{const p=parts.map(units);if(cuts.size>=32||p.some(n=>n<1||(!raw&&n>maximum))||p.reduce((a,b)=>a+b,0)!==run||p.length*rowCount>2000||(requested&&p.length!==Number(requested)))return;const key=p.join(',');if(!cuts.has(key))cuts.set(key,p.map(mm));};
  if(raw)add(manual(total,settings));
  else{
   const original=packer.runPieces(total,options,kerf);add(original);
   const stocks=[...new Set(options.map(units))].sort((a,b)=>a-b),sizes=[...new Set(stocks.flatMap(s=>[s,s-units(kerf)]).filter(n=>n>0))];
   const seeds=sizes.length<=16?sizes:sizes.filter((_,i)=>i===0||i===sizes.length-1||i%Math.ceil(sizes.length/14)===0);
   const minimum=Math.max(1,Math.ceil(run/maximum)),limit=Math.min(2000,run,Math.floor(2000/rowCount));
   const additional=Array.from({length:Math.max(0,Math.min(12,limit-minimum+1))},(_,i)=>minimum+i);
   const counts=requested?[Number(requested)]:[...new Set([original.length,...additional,...seeds.map(s=>Math.ceil(run/s))])].filter(n=>n>0&&n<=limit).sort((a,b)=>a-b).slice(0,16);
   // Reserve space for different piece counts before stock-boundary candidates fill the budget.
   for(const n of counts)add(manual(total,{count:n}));
   for(const n of counts){
    for(const a of seeds){
     if(cuts.size>=31)break;
     if(n===1){add([total]);continue;}
     add(Array(n-1).fill(a/10).concat((run-(n-1)*a)/10));
     for(const b of seeds){
      if(a===b||cuts.size>=31)continue;
      const pivot=Math.floor((run-(n-1)*b)/(a-b)),choices=[0,n-1,pivot-1,pivot,pivot+1,Math.floor((n-1)/2)];
      for(const k of choices)if(k>=0&&k<n){const rest=run-k*a-(n-1-k)*b;if(rest>0)add([...Array(k).fill(a/10),...Array(n-1-k).fill(b/10),rest/10].sort((x,y)=>y-x));}
     }
    }
    add(manual(total,{count:n}));
   }
   if(requested)add(manual(total,{count:requested}));
  }
  const automatic=!raw&&!requested;
  let best=null,lastError=null;const shortlist=[];
  for(const parts of cuts.values())try{
   const installation=rows(total,parts,rowCount,settings.stagger===true,validate?100:0.1),frame=validate?.(installation),packed=packer.packQuick(options,installation.demand,kerf);
   const evaluation=evaluate?.({installation,frame,packed,quick:true}),baseScore=evaluation?.score||[units(packed.total),packed.bins.length,installation.pieceCount],score=automatic?[installation.pieceCount,parts.length,...baseScore]:baseScore;
   const candidate={parts,installation,packed,frame,score,evaluation:evaluation?.result};shortlist.push(candidate);
   if(!best||score.some((v,i)=>score.slice(0,i).every((x,j)=>x===best.score[j])&&v<best.score[i]))best=candidate;
  }catch(e){lastError=e;}
  if(!best)throw lastError||Error('분할 개수에 맞는 재단 조합이 없습니다. 분할 개수와 원자재 길이를 확인해주세요.');
  shortlist.sort((a,b)=>{for(let i=0;i<a.score.length;i++){const difference=a.score[i]-b.score[i];if(difference)return difference;}return 0;});
  const refine=raw?[best]:[...new Set([shortlist[0],shortlist[1],shortlist.find(c=>c.parts.join(',')===packer.runPieces(total,options,kerf).join(','))])].filter(Boolean);
  let refinedBest=null;
  for(const candidate of refine){const packed=packer.pack(options,candidate.installation.demand,kerf),evaluation=evaluate?.({...candidate,packed,quick:false}),baseScore=evaluation?.score||[units(packed.total),packed.bins.length,candidate.installation.pieceCount],score=automatic?[candidate.installation.pieceCount,candidate.parts.length,...baseScore]:baseScore;if(!refinedBest||score.some((v,i)=>score.slice(0,i).every((x,j)=>x===refinedBest.score[j])&&v<refinedBest.score[i]))refinedBest={...candidate,packed,score,evaluation:evaluation?.result};}
  best=refinedBest||best;
  return best;
 }
 function rows(total,base,count,stagger=false,minimumSeamDistance=0.1){
  const run=units(total),a=base.map(units);
  if(!Number.isInteger(count)||count<1||count>2000||!a.length||a.some(n=>!Number.isSafeInteger(n)||n<1)||a.reduce((x,y)=>x+y,0)!==run)throw Error('시공 행과 분할 치수를 확인해주세요.');
  if(count*a.length>2000)throw Error('교차 배치를 포함한 재단품은 2,000개 이하로 계산해주세요.');
  let b=a.slice();
  if(stagger&&a.length>1&&count>1){
   const original=seams(base),starts=[0,...original],distance=units(minimumSeamDistance);
   if(!Number.isSafeInteger(distance)||distance<1)throw Error('이음 최소 간격을 확인해주세요.');
   const minimumPiece=Math.max(1,Math.floor(Math.min(...a)/2),Math.ceil(distance/2));
   const initial=Math.max(1,Math.floor(a[0]/2));let phase=initial,valid=false;
   for(let attempt=0;attempt<4096&&phase<initial+run;attempt++){
    let jump=0;
    for(const start of starts){
     const p=(start+phase)%run;if(p===0)continue;
     if(p<minimumPiece){jump=minimumPiece-p;break;}
     if(run-p<minimumPiece){jump=run-p;break;}
     let lo=0,hi=original.length;while(lo<hi){const mid=(lo+hi)>>1;if(original[mid]<p)lo=mid+1;else hi=mid;}
     for(const joint of [original[lo-1],original[lo]])if(joint!==undefined&&Math.abs(joint-p)<distance){jump=joint+distance-p;break;}
     if(jump)break;
    }
    if(!jump){valid=true;break;}phase+=jump;
   }
   const shift=phase%run;
   if(!valid||!shift)throw Error('교차 가능한 이음 위치가 없습니다. 구간 치수를 늘리거나 교차 이음을 해제해주세요.');
   const cuts=[0,...starts.map(x=>(x+shift)%run).filter(x=>x>0),run].sort((x,y)=>x-y);
   b=cuts.slice(1).map((x,i)=>x-cuts[i]);
  }
  const patterns=[a.map(mm),b.map(mm)],pieceCount=Math.ceil(count/2)*a.length+Math.floor(count/2)*b.length;
  if(pieceCount>2000)throw Error('교차 배치를 포함한 재단품은 2,000개 이하로 계산해주세요.');
  const rowPieces=Array.from({length:count},(_,i)=>patterns[i%2].slice());
  const allSeams=[...new Set(rowPieces.flatMap(seams))].sort((x,y)=>x-y).map(mm);
  return {patterns,rowPieces,demand:rowPieces.flat(),seams:allSeams,pieceCount,staggered:stagger&&count>1&&a.length>1};
 }
 function read(prefix){const q=id=>root.document.getElementById(prefix+id);return{count:q('RunCount').value,lengths:q('RunLengths').value,stagger:q('Stagger').checked};}
 function report(prefix,message=''){const node=root.document.getElementById(prefix+'CalculationStatus');if(node){node.textContent=message?'계산 확인: '+message:'';node.hidden=!message;node.style.display=message?'block':'none';}}
 function restore(prefix,data={}){report(prefix);const q=id=>root.document.getElementById(prefix+id);q('RunCount').value=data?.count??'';q('RunLengths').value=data?.lengths??'';q('Stagger').checked=data?.stagger!==false;}
 function describe(layout){const fmt=n=>Number(n).toLocaleString('ko-KR',{maximumFractionDigits:1});return '기본 행 '+layout.patterns[0].length+'분할 · '+(layout.staggered?'홀수 행: '+layout.patterns[0].map(fmt).join(' + ')+'mm / 짝수 행: '+layout.patterns[1].map(fmt).join(' + ')+'mm':'행당 '+layout.patterns[0].map(fmt).join(' + ')+'mm');}
 const api={manual,rows,optimize,read,restore,describe,report};
 if(typeof module!=='undefined'&&module.exports){module.exports=api;return;}root.RunLayout=api;
 for(const [prefix,anchor]of [['deck','boardOptions'],['louver','louverStockRows']]){
  const section=root.document.createElement('div');section.className='field material-section run-layout-controls';
  section.innerHTML='<h4>상판 분할 / 이음 방법</h4><label class="joist-fixed" for="'+prefix+'Stagger"><input id="'+prefix+'Stagger" type="checkbox" checked>한 행씩 번갈아 교차 이음</label><label for="'+prefix+'RunCount">길이 방향 분할 개수</label><input id="'+prefix+'RunCount" type="number" min="1" max="2000" step="1" inputmode="numeric" placeholder="빈칸: 원자재 길이로 자동 계산"><label for="'+prefix+'RunLengths">구간별 길이 <small>mm · 쉼표로 구분</small></label><input id="'+prefix+'RunLengths" type="text" inputmode="text" placeholder="예: 2000, 2000, 2000"><div class="site-status">빈칸은 원자재에 맞춰 자동 계산합니다. 직접 지정하려면 개수 또는 길이(mm)를 입력하세요. 여러 길이는 쉼표로 구분하고 합계를 시공 길이에 맞춰주세요. 변경 후 계산 버튼을 누르세요.</div>';
  root.document.getElementById(anchor).closest('.material-section').before(section);
  const status=root.document.createElement('div');status.id=prefix+'CalculationStatus';status.className='note';status.setAttribute('role','alert');status.hidden=true;status.style.display='none';root.document.getElementById(prefix==='deck'?'calculate':'louverCalculate').after(status);
  restore(prefix);
 }
})(typeof window==='undefined'?globalThis:window);

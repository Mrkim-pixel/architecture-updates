
/* Lengths are integer tenths of a millimetre internally. No stock is invented. */
(function (root) {
  'use strict';
  const unit = x => Math.round(Number(x) * 10);
  const sum = xs => xs.reduce((a, b) => a + b, 0);
  function usage(stock, lengths, k) {
    const net = sum(lengths), n = lengths.length;
    return usageCount(stock,net,n,k);
  }
  function usageCount(stock, net, n, k) {
    // The factory end needs no cut when the last piece ends exactly there.
    const loss = net + Math.max(0, n - 1) * k === stock ? Math.max(0, n - 1) * k : n * k;
    return { fits: net + loss <= stock, loss, left: stock - net - loss };
  }
  function solvePack(options, values, kerf = 0, search = true) {
    if (!Number.isFinite(+kerf) || kerf < 0) throw Error('톱날 두께를 확인해주세요.');
    if (values.length > 2000) throw Error('한 번에 재단할 수 있는 수량은 2,000개입니다.');
    const stocks = [...new Set(options.map(unit))].sort((a,b)=>a-b), items = values.map(unit).sort((a,b)=>b-a), k = unit(kerf);
    if (!items.length) return { bins: [], exact: true, total: 0, waste: 0, loss: 0 };
    if (!stocks.length || stocks.some(x=>!Number.isSafeInteger(x)||x<=0) || items.some(x=>!Number.isSafeInteger(x)||x<=0)) throw Error('원자재와 재단 길이를 올바르게 입력해주세요.');
    for (const x of items) if (!stocks.some(s=>usage(s,[x],k).fits)) throw Error((x/10).toLocaleString()+'mm 품목을 재단할 원자재가 없습니다. 톱날 두께와 원자재 길이를 확인해주세요.');
    const frequencies=new Map();for(const x of items)frequencies.set(x,(frequencies.get(x)||0)+1);
    const types = [...frequencies.keys()], counts = [...frequencies.values()];
    const makeBin = (stock,used) => ({ stock, used, net:sum(used), ...usage(stock,used,k) });
    const score = bins => [sum(bins.map(b=>b.stock)), bins.length];
    const better = (a,b) => !b || a[0]<b[0] || (a[0]===b[0] && a[1]<b[1]);
    // Several deterministic best-fit candidates provide a fast feasible upper bound.
    function greedy(cap) {
      const bins=[];
      for(const x of items) {
        let chosen=-1, left=Infinity;
        bins.forEach((b,i)=>{const u=usageCount(b.stock,b.net+x,b.used.length+1,k);if(u.fits&&u.left<left){chosen=i;left=u.left;}});
        if(chosen>=0){const b=bins[chosen];b.used.push(x);b.net+=x;Object.assign(b,usageCount(b.stock,b.net,b.used.length,k));}
        else {const stock=cap && usage(cap,[x],k).fits?cap:stocks.find(s=>usage(s,[x],k).fits);bins.push(makeBin(stock,[x]));}
      }
      return bins.map(b=>makeBin(stocks.find(s=>usage(s,b.used,k).fits),b.used));
    }
    // Identical pieces use the exact quantity path directly. The smallest-capacity
    // greedy candidate duplicates greedy(0), so mixed jobs only compare larger caps.
    let best=types.length===1?[]:greedy(0);
    if(types.length>1)for(const s of stocks.slice(1)){const candidate=greedy(s);if(better(score(candidate),score(best)))best=candidate;}
    // Compare the cost of extending an open bar with buying another bar.
    // Keep all original candidates, so this extra heuristic cannot worsen them.
    if(types.length>1 && stocks.length>1 && items.length<=300){
      const flexible=[];
      for(const x of items){
        let chosen=-1,stock=stocks.find(s=>usageCount(s,x,1,k).fits),extra=stock,left=usageCount(stock,x,1,k).left;
        for(let i=0;i<flexible.length;i++){
          const b=flexible[i],s=stocks.find(s=>s>=b.stock&&usageCount(s,b.net+x,b.used.length+1,k).fits);
          if(s===undefined)continue;
          const delta=s-b.stock,remaining=usageCount(s,b.net+x,b.used.length+1,k).left;
          if(delta<extra||delta===extra&&remaining<left){chosen=i;stock=s;extra=delta;left=remaining;}
        }
        if(chosen<0)flexible.push(makeBin(stock,[x]));
        else{const b=flexible[chosen];flexible[chosen]=makeBin(stock,b.used.concat(x));}
      }
      if(better(score(flexible),score(best)))best=flexible;
    }
    // Enumerate feasible patterns and memoize remaining quantities for manageable jobs.
    // Large jobs keep the best feasible candidate rather than blocking the interface.
    let exact=false, work=0;
    // Quantity DP proves the optimum for repeated identical pieces, including large jobs.
    if(types.length===1){
      const n=items.length,x=types[0],patterns=[];
      if(stocks.length===1){
        const stock=stocks[0];let capacity=Math.min(n,Math.floor((stock+k)/(x+k)));
        while(capacity>0&&!usageCount(stock,x*capacity,capacity,k).fits)capacity--;
        for(let left=n;left>0;){const qty=Math.min(left,capacity);best.push(makeBin(stock,Array(qty).fill(x)));left-=qty;}
        exact=true;
      }else{
      for(let qty=1;qty<=n;qty++){const stock=stocks.find(s=>usageCount(s,x*qty,qty,k).fits);if(!stock)break;patterns.push({qty,stock});}
      const costs=Array(n+1).fill(Infinity),numbers=Array(n+1).fill(Infinity),choice=Array(n+1);costs[0]=numbers[0]=0;
      for(let rest=1;rest<=n;rest++)for(const p of patterns){if(p.qty>rest)break;const cost=costs[rest-p.qty]+p.stock,count=numbers[rest-p.qty]+1;if(cost<costs[rest]||cost===costs[rest]&&count<numbers[rest]){costs[rest]=cost;numbers[rest]=count;choice[rest]=p;}}
      best=[];for(let rest=n;rest>0;){const p=choice[rest];best.push(makeBin(p.stock,Array(p.qty).fill(x)));rest-=p.qty;}exact=true;
      }
    }
    if(search && !exact && types.length<=10 && counts.reduce((a,n)=>a*(n+1),1)<=50000 && items.length<=300) {
      try {
        const patterns=[];
        function enumerate(i, chosen, lengths, net) {
          if(++work>150000) throw Error('budget');
          if(i===types.length){if(!lengths.length)return;const stock=stocks.find(s=>usage(s,lengths,k).fits);if(stock)patterns.push({counts:chosen.slice(),bin:makeBin(stock,lengths.slice())});return;}
          const max=Math.min(counts[i],Math.floor((stocks[stocks.length-1]+k-net)/(types[i]+k)));
          for(let n=0;n<=max;n++){chosen[i]=n;enumerate(i+1,chosen,lengths.concat(Array(n).fill(types[i])),net+n*(types[i]+k));}
        }
        enumerate(0,[],[],0);
        const byType=types.map((_,i)=>patterns.filter(p=>p.counts[i]));
        const memo=new Map();
        function solve(rest) {
          if(++work>350000) throw Error('budget');
          const pivot=rest.findIndex(n=>n>0);if(pivot<0)return {cost:[0,0],pattern:null,next:null};
          const key=rest.join(',');if(memo.has(key))return memo.get(key);
          let answer=null;
          for(const p of byType[pivot]) {
            if(++work>350000)throw Error('budget');
            if(p.counts.some((n,i)=>n>rest[i]))continue;
            const tail=solve(rest.map((n,i)=>n-p.counts[i]));
            if(!tail)continue;
            const cost=[tail.cost[0]+p.bin.stock,tail.cost[1]+1];
            if(better(cost,answer?.cost))answer={cost,pattern:p,next:tail};
          }
          memo.set(key,answer);return answer;
        }
        let result=solve(counts);if(result){best=[];while(result.pattern){best.push(result.pattern.bin);result=result.next;}exact=true;}
      } catch(e) {if(e.message!=='budget')throw e;}
    }
    const bins=best.map(b=>({stock:b.stock/10,used:b.used.map(x=>x/10),left:b.left/10,loss:b.loss/10}));
    return {bins,exact,total:sum(bins.map(b=>b.stock)),waste:sum(bins.map(b=>b.left)),loss:sum(bins.map(b=>b.loss))};
  }
  // Keep a small reusable cache for repeated calculations without sharing mutable bins.
  const cache = new Map();
  function pack(options, values, kerf = 0) {
    // Validate before the cache lookup: JSON encodes NaN/Infinity as null.
    // Otherwise a previously cached null/zero kerf could mask an invalid input.
    if(!Number.isFinite(Number(kerf))||Number(kerf)<0)throw Error('톱날 두께를 확인해주세요.');
    if(values.length>2000)return solvePack(options,values,kerf);
    const key=JSON.stringify([[...new Set(options)].sort((a,b)=>a-b),values.slice().sort((a,b)=>b-a),kerf]);
    let result=cache.get(key);
    if(!result){result=solvePack(options,values,kerf);if(cache.size>=16)cache.delete(cache.keys().next().value);}
    else cache.delete(key);
    cache.set(key,result);
    return {...result,bins:result.bins.map(b=>({...b,used:b.used.slice()}))};
  }
  function groups(bins) {
    const map=new Map();
    bins.forEach(b=>{const sorted=b.used.map((length,i)=>({length,role:b.roles?.[i]||''})).sort((a,b)=>b.length-a.length||a.role.localeCompare(b.role)),used=sorted.map(p=>p.length),roles=sorted.map(p=>p.role),key=JSON.stringify([b.stock,used,b.loss,b.material||'',b.roles?roles:null]);if(!map.has(key))map.set(key,{...b,used,...(b.roles?{roles}:{}),...(b.id?{sourceIds:[]}:{}),qty:0});const group=map.get(key);group.qty++;if(b.id)group.sourceIds.push(b.id);});
    return [...map.values()];
  }
  // Fill existing offcuts first; only the unmet quantity needs new raw stock.
  // Recompute complete-bin kerf so an exact factory-end finish is counted once.
  function addRepeated(options,existing,length,quantity,kerf=0){
    if(!Number.isInteger(quantity)||quantity<0||quantity>2000)throw Error('기둥 수량은 2,000개 이하로 계산해주세요.');
    const bins=existing.map(b=>({...b,used:b.used.slice(),...(b.roles?{roles:b.roles.slice()}:{}),added:0}));
    if(!quantity)return{bins,additional:pack(options,[],kerf),reused:0};
    pack(options,[length],kerf);
    const x=unit(length),k=unit(kerf);let remaining=quantity;
    const available=bins.map((b,index)=>{
      const stock=unit(b.stock),net=sum(b.used.map(unit)),n=b.used.length;
      let capacity=Math.max(0,Math.min(quantity,Math.floor((stock+k-net-n*k)/(x+k))));
      while(capacity>0&&!usageCount(stock,net+capacity*x,n+capacity,k).fits)capacity--;
      return{index,capacity,stock,net,n};
    }).sort((a,b)=>b.capacity-a.capacity||a.index-b.index);
    for(const a of available){const take=Math.min(remaining,a.capacity);if(!take)continue;const b=bins[a.index],u=usageCount(a.stock,a.net+take*x,a.n+take,k);b.used.push(...Array(take).fill(x/10));b.added=take;b.left=u.left/10;b.loss=u.loss/10;remaining-=take;if(!remaining)break;}
    return{bins,additional:pack(options,Array(remaining).fill(x/10),kerf),reused:quantity-remaining};
  }
  // Split only when a run exceeds every stock. Repeated runs are packed together.
  function runPieces(length, options, kerf) {
    const target=unit(length),stocks=options.map(unit).sort((a,b)=>b-a),k=unit(kerf),parts=[];
    let left=target;
    if(!stocks.length)throw Error('원자재 길이를 입력해주세요.');
    while(left>stocks[0]){parts.push(stocks[0]);left-=stocks[0];if(parts.length>2000)throw Error('시공 길이가 너무 큽니다.');}
    if(left>0){if(!stocks.some(s=>usage(s,[left],k).fits))throw Error('끝부분 재단에 필요한 톱날 여유가 부족합니다.');parts.push(left);}
    return parts.map(x=>x/10);
  }
  // Share straight (unspliced) cuts across roles. Compare pooled packing and
  // frame-offcut-first column packing; never buy more length than the baseline.
  function packShared(options,original,kerf=0){
    const records=original.flatMap(b=>b.used.map((length,i)=>({length,role:b.roles[i],jobId:b.jobIds[i]})));
    const bind=(bins,known=false)=>{
      const queues=new Map();for(const r of records){const key=known?r.role+'|'+r.length:String(r.length);if(!queues.has(key))queues.set(key,[]);queues.get(key).push(r);}
      return bins.map(b=>{const cuts=b.used.map((length,i)=>{const r=queues.get(known?b.roles[i]+'|'+length:String(length))?.shift();if(!r)throw Error('공용 재단 품목 정보가 일치하지 않습니다.');return r;});const roles=cuts.map(r=>r.role);return{stock:b.stock,used:b.used.slice(),left:b.left,loss:b.loss,roles,jobIds:cuts.map(r=>r.jobId),owner:roles.includes('joist')?'joist':roles.includes('bearer')?'bearer':'post'};});
    };
    const candidate=(bins,exact=false)=>({bins,total:sum(bins.map(b=>b.stock)),waste:sum(bins.map(b=>b.left)),loss:sum(bins.map(b=>b.loss)),exact});
    const choices=[candidate(bind(original,true))];
    if(records.length<=2000){const p=pack(options,records.map(r=>r.length),kerf);choices.push(candidate(bind(p.bins),p.exact));}
    const frame=original.filter(b=>b.owner!=='post'),posts=records.filter(r=>r.role==='post'),frames=[frame];
    const frameRecords=records.filter(r=>r.role!=='post');
    if(frameRecords.length<=2000){
      const p=pack(options,frameRecords.map(r=>r.length),kerf),queues=new Map();
      for(const r of frameRecords){if(!queues.has(r.length))queues.set(r.length,[]);queues.get(r.length).push(r);}
      frames.push(p.bins.map(b=>{const cuts=b.used.map(n=>queues.get(n).shift());return{...b,roles:cuts.map(r=>r.role)};}));
    }
    if(posts.length<=2000&&(!posts.length||posts.every(r=>r.length===posts[0].length)))for(const frameBins of frames){
      const p=addRepeated(options,frameBins,posts[0]?.length||0,posts.length,kerf);
      p.bins.forEach(b=>b.roles.push(...Array(b.added).fill('post')));p.additional.bins.forEach(b=>b.roles=b.used.map(()=> 'post'));
      choices.push(candidate(bind([...p.bins,...p.additional.bins],true)));
    }
    const sharedLength=p=>sum(p.bins.map(b=>sum(b.used.filter((_,i)=>b.roles[i]!==b.owner))));
    choices.sort((a,b)=>unit(a.total)-unit(b.total)||a.bins.length-b.bins.length||a.bins.filter(b=>b.owner==='post').length-b.bins.filter(b=>b.owner==='post').length||unit(sharedLength(b))-unit(sharedLength(a))||unit(a.loss)-unit(b.loss));
    return choices[0];
  }
  const packQuick=(options,values,kerf=0)=>solvePack(options,values,kerf,false);
  const api={pack,packQuick,groups,runPieces,addRepeated,packShared};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else root.CuttingEngine=api;
})(typeof window==='undefined'?globalThis:window);
/* Shared raw-stock identity, colors and quantity reporting for cutting tools. */
(function(root){
  'use strict';
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>Number(n).toLocaleString('ko-KR',{maximumFractionDigits:1}),unit=n=>Math.round(Number(n)*10)/10;
  const key=(material,length,width=0)=>JSON.stringify([String(material).trim(),unit(length),unit(width)]);
  // Distinct hue families identify stocks; dark fills keep white cut labels legible.
  const color=i=>['#194B7A','#98521B','#116C64','#754C92','#963D50','#596B26','#745342','#46586C'][i]||'hsl('+((i*137.508)%360).toFixed(2)+',46%,30%)';
  const previewColor=i=>['#9AB8D2','#D2AE7C','#91B7A7','#B3A1C7','#CC9DA5','#B4BD85'][i]||'hsl('+((i*137.508)%360).toFixed(2)+',32%,64%)';
  const sheetColor=color;
  function create(stocks,bins,mode='linear'){
    const sheet=mode==='sheet',map=new Map();
    stocks.forEach(s=>{const material=String(s.material||'').trim(),length=unit(s.length),width=sheet?unit(s.width):0;if(!material||!Number.isFinite(length)||length<=0||(sheet&&(!Number.isFinite(width)||width<=0)))throw Error('원자재 종류와 규격을 확인해주세요.');const id=key(material,length,width);if(!map.has(id))map.set(id,{material,length,width,quantity:0,pieces:0,waste:0,loss:0});});
    bins.forEach(b=>{const r=map.get(key(b.material,sheet?b.length:b.stock,sheet?b.width:0));if(!r)throw Error('수량표의 원자재 규격을 확인해주세요.');r.quantity++;r.pieces+=sheet?b.parts.length:b.used.length;r.waste+=sheet?b.waste:b.left;r.loss+=b.loss;});
    const rows=[...map.values()].sort((a,b)=>a.material.localeCompare(b.material,'ko')||a.length-b.length||a.width-b.width).map((r,i)=>({...r,waste:Math.round(r.waste*100)/100,loss:Math.round(r.loss*100)/100,code:(sheet?'P':'L')+(i+1),color:sheet?sheetColor(i):color(i)}));
    const indexed=new Map(rows.map(r=>[key(r.material,r.length,r.width),r]));
    return{rows,mode,lookup:(material,length,width=0)=>indexed.get(key(material,length,width)),totals:rows.reduce((s,r)=>({quantity:s.quantity+r.quantity,pieces:s.pieces+r.pieces,waste:s.waste+r.waste,loss:s.loss+r.loss}),{quantity:0,pieces:0,waste:0,loss:0})};
  }
  const swatch=r=>'<i class="stock-report-swatch" style="background:'+r.color+'" aria-hidden="true"></i>';
  const legend=report=>report.rows.filter(r=>r.quantity).map(r=>'<span class="stock-report-chip">'+swatch(r)+r.code+' · '+esc(r.material)+' '+fmt(r.length)+(report.mode==='sheet'?' × '+fmt(r.width):'')+'mm</span>').join('');
  function summary(report){
    const unit=report.mode==='sheet'?'장':'본';
    return '<b>자재별 수량</b>'+report.rows.filter(r=>r.quantity>0).map(r=>'<div class="board-stock-row stock-summary-row" data-stock-code="'+r.code+'" data-stock-length="'+r.length+'" data-stock-width="'+(r.width||0)+'" data-quantity="'+r.quantity+'"><span>'+swatch(r)+' '+r.code+' · '+esc(r.material)+' '+fmt(r.length)+(report.mode==='sheet'?' × '+fmt(r.width):'')+'mm</span><b>'+fmt(r.quantity)+unit+'</b></div>').join('');
  }
  function table(report){
    const sheet=report.mode==='sheet',countUnit=sheet?'장':'본',amount=n=>sheet?(n/1e6).toFixed(3)+'㎡':fmt(n)+'mm';
    return '<table class="cut-table"><thead><tr><th>색상·번호</th><th>자재 종류</th><th>원자재 규격</th><th>필요 수량</th><th>재단품 수량</th><th>잔여 합계</th><th>톱날 손실 합계</th></tr></thead><tbody>'+report.rows.map(r=>'<tr data-stock-code="'+r.code+'" data-quantity="'+r.quantity+'" data-pieces="'+r.pieces+'"'+(!r.quantity?' class="stock-report-unused"':'')+'><td>'+swatch(r)+' '+r.code+'</td><td>'+esc(r.material)+'</td><td>'+fmt(r.length)+(sheet?' × '+fmt(r.width):'')+'mm</td><td>'+r.quantity+countUnit+(!r.quantity?' · 미사용':'')+'</td><td>'+r.pieces+'개</td><td>'+amount(r.waste)+'</td><td>'+amount(r.loss)+'</td></tr>').join('')+'</tbody><tfoot><tr><td colspan="3">합계</td><td>'+report.totals.quantity+countUnit+'</td><td>'+report.totals.pieces+'개</td><td>'+amount(report.totals.waste)+'</td><td>'+amount(report.totals.loss)+'</td></tr></tfoot></table>';
  }
  const utilization=(net,total)=>total>0?(Math.max(0,Math.min(1,net/total))*100).toFixed(1):'0.0';
  function displayUtilization(element,value='—'){
    if(!element)return;element.textContent=value;
    const card=element.closest?.('.result');if(!card)return;
    const number=Number(value),ready=String(value).trim()!==''&&Number.isFinite(number);
    card.classList.add('utilization-result');card.dataset.utilizationReady=String(ready);
    card.style.setProperty('--utilization',(ready?Math.max(0,Math.min(100,number)):0)+'%');
  }
  const api={create,swatch,legend,table,summary,utilization,displayUtilization,color,previewColor};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.StockReport=api;
})(typeof window==='undefined'?globalThis:window);
/* One explicit calculation entry point for each planner. */
(() => {
  'use strict';
  const q=id=>document.getElementById(id), E=window.CuttingEngine, R=window.StockReport;
  const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=x=>Number(x).toLocaleString('ko-KR',{maximumFractionDigits:1});
  const value=id=>Number(q(id).value);
  const text=(id,s)=>{if(!q(id))return;if(['deckSteelUsage','deckBoardUsage','cutUsage'].includes(id))R.displayUtilization(q(id),s);else q(id).textContent=s;};
  const usage=plans=>R.utilization(plans.reduce((n,p)=>n+p.bins.reduce((s,b)=>s+b.used.reduce((a,x)=>a+x,0),0),0),plans.reduce((n,p)=>n+p.total,0));
  function positive(id,label){const n=value(id);if(!q(id).value.trim()||!Number.isFinite(n)||n<=0)throw Error(label+'을(를) 입력해주세요.');return n;}
  function options(id){const xs=q(id).value.split(',').map(x=>Math.round(Number(x.trim())*10)/10);if(!xs.length||xs.some(x=>!Number.isFinite(x)||x<=0))throw Error('원자재 길이를 쉼표로 구분해 입력해주세요.');return [...new Set(xs)].sort((a,b)=>a-b);}
  function kerf(id){const n=value(id);if(!Number.isFinite(n)||n<0)throw Error('톱날 두께를 확인해주세요.');return n;}
  const repeat=(pieces,n)=>{if(pieces.length*n>2000)throw Error('재단 수량이 너무 많습니다. 구역을 나눠 계산해주세요.');return Array.from({length:n},()=>pieces).flat();};
  const roleName={joist:'장선',bearer:'멍에',post:'기둥','reuse-joist':'장선 재활용','reuse-bearer':'멍에 재활용','reuse-post':'기둥 재활용'};
  function partsText(parts,roles){const m=new Map();parts.forEach((x,i)=>{const label=(roles?roleName[roles[i]]+' ':'')+fmt(x)+'mm';m.set(label,(m.get(label)||0)+1);});return [...m].map(([label,n])=>label+' × '+n+'개').join(' + ');}
  const deckColor=i=>R.color(i);
  const deckSwatch=r=>'<i class="deck-material-swatch" style="background:'+r.color+'" aria-hidden="true"></i>';
  function deckMaterials(steelOptions,boardOptions,jp,bp,pp,boards){
    const rows=[],map=new Map();
    for(const [type,options,prefix,label] of [['steel',steelOptions,'A','아연 각관'],['board',boardOptions,'D','데크 상판']])options.slice().sort((a,b)=>a-b).forEach((stock,i)=>{const row={type,stock,code:prefix+(i+1),label,color:deckColor(rows.length,type==='board'&&i===1),joist:0,bearer:0,post:0,board:0,quantity:0,pieces:0,reusePieces:0,reuseLength:0};rows.push(row);map.set(type+'|'+stock,row);});
    for(const [type,role,plan] of [['steel','joist',jp],['steel','bearer',bp],['steel','post',pp],['board','board',boards]])plan.bins.forEach(b=>{const row=map.get(type+'|'+b.stock);row[role]++;row.quantity++;row.pieces+=b.used.length;b.used.forEach((length,i)=>{if(b.roles?.[i]?.startsWith('reuse-')){row.reusePieces++;row.reuseLength+=length;}});});
    return {rows,map};
  }
  function bars(bins,color,identify){return E.groups(bins).map(b=>{
    const material=identify?.(b.stock);if(material)color=material.color;
    const segment=(length,label,bg,recycled=false)=>length?'<span title="'+escape(label)+'" style="box-sizing:border-box;flex:0 0 '+(length/b.stock*100)+'%;min-width:0;overflow:hidden;display:flex;align-items:center;justify-content:center;background:'+bg+(recycled?';background-image:repeating-linear-gradient(135deg,transparent,transparent 7px,#ffffff33 7px,#ffffff33 10px)':'')+';color:#fff;font-size:10px;border-right:1px solid #fff">'+label+'</span>':'';
    const cuts=b.used.map((x,i)=>segment(x,(b.roles?roleName[b.roles[i]]+' ':'')+fmt(x)+'mm',color,b.roles?.[i]?.startsWith('reuse-'))).join('');
    return '<div class="cut-row"'+(material?' data-stock-code="'+material.code+'"':'')+'><div class="cut-label"><b>'+(material?deckSwatch(material)+' '+material.code+' · ':'')+'원자재 '+fmt(b.stock)+'mm · × '+b.qty+'본'+(b.sourceIds?' · '+b.sourceIds.join(', '):'')+'</b><span>'+partsText(b.used,b.roles)+' · 톱날 손실 '+fmt(b.loss)+'mm · 잔여 '+fmt(b.left)+'mm</span></div><div class="bar-track" style="display:flex;width:100%;height:34px;overflow:hidden;background:#e8eee9">'+cuts+segment(b.loss,'톱날','#c65353')+segment(b.left,'잔여 '+fmt(b.left)+'mm','#87958c')+'</div></div>';
  }).join('');}
  const diagram=(title,plan,color,identify)=>'<div class="diagram-group"><b>'+title+' · 원자재 '+plan.bins.length+'본</b>'+bars(plan.bins,color,identify)+'</div>';
  function reuseQuantityTable(direct,assemblies,identify){
    const groups=new Map();
    const add=(kind,role,stock,length)=>{const key=[kind,role,stock,length].join('|');if(!groups.has(key))groups.set(key,{kind,role,stock,length,qty:0});groups.get(key).qty++;};
    direct.forEach(r=>add('잔재 단일 재단','post',r.stock,r.length));
    assemblies.forEach(a=>a.parts.forEach(p=>add(a.parts.length===1?'잔재 단일 재단':'잔재 이어쓰기 조각',a.role,p.stock,p.length)));
    const rows=[...groups.values()].sort((a,b)=>a.stock-b.stock||a.length-b.length);
    if(!rows.length)return '<div class="site-status">잔여 자재 활용 없음 · 추가 구매 0본</div>';
    return '<div style="max-width:100%;overflow-x:auto"><table class="cut-table"><thead><tr><th>원자재 출처</th><th>활용 방식</th><th>용도</th><th>재단 길이</th><th>조각 수량</th><th>활용 길이 합계</th></tr></thead><tbody>'+rows.map(r=>'<tr data-reuse-quantity="'+r.qty+'" data-reuse-length="'+(r.length*r.qty)+'"><td>'+deckSwatch(identify(r.stock))+' '+identify(r.stock).code+' · '+fmt(r.stock)+'mm</td><td>'+r.kind+'</td><td>'+roleName[r.role]+'</td><td>'+fmt(r.length)+'mm</td><td>'+r.qty+'개</td><td>'+fmt(r.length*r.qty)+'mm</td></tr>').join('')+'</tbody><tfoot><tr><td colspan="4">잔재 활용 합계 · 구매 원자재 합계에 미가산</td><td>'+rows.reduce((n,r)=>n+r.qty,0)+'개</td><td>'+fmt(rows.reduce((n,r)=>n+r.length*r.qty,0))+'mm</td></tr></tfoot></table></div><div class="site-status">위 구매 원자재에서 나온 잔재입니다. 조각 수량은 완성 부재 수량과 다르며 구매 본수에 더하지 않습니다.</div>';
  }
  function reuseSourceDrawings(result,identify,k){
    if(!result.assemblies.length)return '<div class="site-status">기둥 재활용 0개 · 톱날 손실 0mm · 잔여 — · 연결 구성 — · 연결 위치 —</div>';
    const grouped=new Map();
    for(const b of result.bins){
      const pieces=b.used.map((length,i)=>({length,role:b.roles[i]})).filter(p=>p.role.startsWith('reuse-'));
      if(!pieces.length)continue;
      const base=b.used.filter((_,i)=>!b.roles[i].startsWith('reuse-')),net=base.reduce((n,x)=>n+Math.round(x*10),0),stock=Math.round(b.stock*10),blade=Math.round(k*10),n=base.length;
      const baseLoss=n?(net+(n-1)*blade===stock?(n-1)*blade:n*blade):0;
      const available=(stock-net-baseLoss)/10,loss=Math.round((b.loss-baseLoss/10)*10)/10;
      const key=JSON.stringify([b.stock,available,pieces.map(p=>[p.length,p.role]),loss,b.left]);
      if(!grouped.has(key))grouped.set(key,{stock:b.stock,available,pieces,loss,left:b.left,sources:[]});
      grouped.get(key).sources.push(b.id);
    }
    const sourceDrawings=[...grouped.values()].sort((a,b)=>a.available-b.available||a.stock-b.stock).map(g=>{
      const m=identify(g.stock),segment=(length,label,color)=>length?'<span title="'+escape(label)+'" style="box-sizing:border-box;flex:0 0 '+(length/g.available*100)+'%;min-width:0;overflow:hidden;display:flex;align-items:center;justify-content:center;border-right:1px solid #fff;background:'+color+';color:#fff;font-size:10px">'+escape(label)+'</span>':'';
      return '<div class="reuse-source-row reuse-row" data-offcut-length="'+g.available+'" data-offcut-loss="'+g.loss+'" data-offcut-left="'+g.left+'" data-offcut-used="'+g.pieces.reduce((n,p)=>n+p.length,0)+'" data-offcut-quantity="'+g.sources.length+'"><div class="site-status reuse-stock-length">재활용 자재 길이: '+fmt(g.available)+'mm × '+g.sources.length+'개</div><b>'+partsText(g.pieces.map(p=>p.length),g.pieces.map(p=>p.role))+' × '+g.sources.length+'묶음</b><div class="bar-track" style="display:flex;width:100%;height:34px;overflow:hidden;background:#e8eee9">'+g.pieces.map(p=>segment(p.length,roleName[p.role]+' '+fmt(p.length)+'mm',m.color)).join('')+segment(g.loss,'톱날 손실 '+fmt(g.loss)+'mm','#c65353')+segment(g.left,'잔여 '+fmt(g.left)+'mm','#87958c')+'</div><div class="site-status">톱날 손실 '+fmt(g.loss)+'mm · 잔여 '+fmt(g.left)+'mm</div></div>';
    }).join('');
    const connections=new Map();
    for(const a of result.assemblies.filter(a=>a.parts.length>1)){
      const key=JSON.stringify([a.role,a.length,a.parts.map(p=>[p.stock,p.length])]);
      if(!connections.has(key))connections.set(key,[]);connections.get(key).push(a);
    }
    const connectionDrawings=[...connections.values()].sort((a,b)=>a[0].length-b[0].length).map(list=>{
      const a=list[0];
      const segments=a.parts.map((p,i)=>'<span class="reuse-connected-piece" style="flex:0 0 '+(p.length/a.length*100)+'%;background:'+identify(p.stock).color+'" title="'+escape('연결 구성: '+fmt(p.length)+'mm')+'">'+fmt(p.length)+'mm</span>').join('');
      let offset=0;const joints=a.parts.slice(0,-1).map((p,i)=>{offset+=p.length;return{index:i+1,position:offset};});
      return '<div class="reuse-connection-row reuse-row" data-member-length="'+a.length+'" data-member-quantity="'+list.length+'"><b>'+roleName[a.role]+' 재활용 '+fmt(a.length)+'mm × '+list.length+'개</b><div class="reuse-assembly-track bar-track">'+segments+joints.map(j=>'<i class="reuse-joint" data-joint-position="'+j.position+'" style="left:'+(j.position/a.length*100)+'%" title="연결 위치 '+j.index+' · '+fmt(j.position)+'mm"></i>').join('')+'</div><div class="site-status">연결 구성: '+a.parts.map(p=>fmt(p.length)+'mm').join(' + ')+' = '+fmt(a.length)+'mm<br>연결 위치: '+joints.map(j=>j.index+'번 '+fmt(j.position)+'mm').join(' · ')+'</div></div>';
    }).join('');
    return sourceDrawings+(connectionDrawings?'<div class="reuse-integrated-connections">'+connectionDrawings+'</div>':'');
  }
  function notice(id,message){q(id).innerHTML='<div class="note" role="status">'+escape(message)+'</div>';}
  function deck(){
    window.RunLayout.report('deck');
    try {
      const baseL=positive('length','시공길이'),baseW=positive('width','시공폭'),spacing=Math.min(1200,Math.max(500,positive('bearer','멍에 간격'))),bw=positive('boardWidth','상판 폭'),k=kerf('sawKerf');
      const margin=value('marginPercent');
      if(!Number.isFinite(margin)||margin<0||margin>100)throw Error('여유율은 0~100% 범위로 입력해주세요.');
      const axis=document.querySelector('[data-axis].active')?.dataset.axis||'length',fast=document.querySelector('[data-f].active')?.dataset.f||'clip';
      const L=axis==='length'?baseL:baseW,W=axis==='length'?baseW:baseL,maxJoist=positive('joistSpacing','장선 간격'),fixedJoist=q('joistFixed').checked;
      const steelOptions=options('steelOptions'),boardOptions=options('boardOptions'),rowCount=Math.ceil(W/bw),settings=window.RunLayout.read('deck');
      const postLength=Math.round(value('deckHeight')*10)/10;
      if(!Number.isFinite(postLength)||postLength<0)throw Error('기둥 재단 높이는 0 이상으로 입력해주세요.');
      const bearers=Math.ceil(W/spacing)+1,postsPerBearer=Math.ceil(L/spacing)+1,postCount=postLength>0?bearers*postsPerBearer:0,spliceEnabled=q('steelSplice').checked;
      const minimum=spliceEnabled?value('steelReuseMinimum'):0;
      if(!Number.isFinite(minimum)||minimum<0)throw Error('잔재 최소 사용 가능 길이는 0 이상으로 입력해주세요.');
      const frameInput={length:L,width:W,bearers,postLength,postCount,options:steelOptions,kerf:k,splice:spliceEnabled,minimum};
      const arrangement=window.RunLayout.optimize(L,boardOptions,rowCount,settings,k,installation=>window.DeckLayout.frameRows(L,maxJoist,fixedJoist,installation.rowPieces),({frame,installation,packed,quick})=>{
        const result=window.FrameStock.calculate({...frameInput,joists:frame.positions.length},quick);
        return{result,score:[Math.round((packed.total+result.total)*10),packed.bins.length+result.quantity,frame.seams.length,frame.positions.length,installation.pieceCount]};
      });
      const installation=arrangement.installation,layout=arrangement.frame,joistPositions=layout.positions,joins=layout.seams.length,regularJoists=layout.regularCount,joists=joistPositions.length;
      const {jp,bp,pp,recycling}=arrangement.evaluation,boards=arrangement.packed;
      ['deckReuseSection','deckReuseDrawingSection','deckReuseQuantitySection'].forEach(id=>{if(q(id))q(id).hidden=!spliceEnabled;});
      const steelPlans=[jp,bp,pp],steelCount=steelPlans.reduce((n,p)=>n+p.bins.length,0);
      const inventory=deckMaterials(steelOptions,boardOptions,jp,bp,pp,boards),steelSource=n=>inventory.map.get('steel|'+n),boardSource=n=>inventory.map.get('board|'+n);
      q('steelPlan').innerHTML='<b>각관 자재별 수량</b>'+inventory.rows.filter(r=>r.type==='steel'&&r.quantity).map(r=>'<div class="board-stock-row steel-stock-row" data-stock-length="'+r.stock+'" data-quantity="'+r.quantity+'"><span>'+deckSwatch(r)+' '+r.code+' · '+fmt(r.stock)+'mm</span><b>'+r.quantity+'본</b></div>').join('')+'<div class="site-status">공용 재단 포함 · 톱날 손실 '+fmt(steelPlans.reduce((n,p)=>n+p.loss,0))+'mm · 잔여 '+fmt(steelPlans.reduce((n,p)=>n+p.waste,0))+'mm</div>';
      q('deckMaterialLegend').innerHTML=inventory.rows.filter(r=>r.quantity).map(r=>'<span class="deck-material-chip">'+deckSwatch(r)+r.code+' · '+r.label+' '+fmt(r.stock)+'mm</span>').join('');
      q('deckMaterialQuantities').innerHTML='<table class="cut-table"><thead><tr><th>색상·번호</th><th>자재</th><th>원자재 길이</th><th>장선용·공용</th><th>멍에용·공용</th><th>기둥 전용</th><th>상판용</th><th>원자재 합계</th><th>재단 조각 수량</th></tr></thead><tbody>'+inventory.rows.map(r=>'<tr data-stock-code="'+r.code+'" data-type="'+r.type+'" data-quantity="'+r.quantity+'" data-joist="'+r.joist+'" data-bearer="'+r.bearer+'" data-post="'+r.post+'" data-board="'+r.board+'"'+(!r.quantity?' class="deck-unused"':'')+'><td>'+deckSwatch(r)+' '+r.code+'</td><td>'+r.label+'</td><td>'+fmt(r.stock)+'mm</td><td>'+r.joist+'본</td><td>'+r.bearer+'본</td><td>'+r.post+'본</td><td>'+r.board+'본</td><td>'+r.quantity+'본'+(!r.quantity?' · 미사용':'')+'</td><td>'+r.pieces+'개</td></tr>').join('')+'</tbody><tfoot><tr><td colspan="3">합계</td><td>'+jp.bins.length+'본</td><td>'+bp.bins.length+'본</td><td>'+pp.bins.length+'본</td><td>'+boards.bins.length+'본</td><td>'+(steelCount+boards.bins.length)+'본</td><td>'+inventory.rows.reduce((n,r)=>n+r.pieces,0)+'개</td></tr></tfoot></table><div class="site-status">각관 '+steelCount+'본(장선 '+jp.bins.length+'본 + 멍에 '+bp.bins.length+'본 + 기둥 추가 '+pp.bins.length+'본) · 상판 '+boards.bins.length+'본. '+(spliceEnabled?'잔재 활용은 아래 별도 표에 표시합니다.':'이어 붙이지 않고 장선·멍에·기둥을 공용 재단합니다. 한 원자재는 대표 용도에 한 번만 집계합니다.')+' 재활용 조각은 위 원자재 안에 포함되며 구매 수량에 중복 가산하지 않습니다. 기둥 전용은 기둥만 재단하는 구매 본수이며, 혼합 재단한 각관은 장선·멍에 공용에 포함합니다. 손실은 붉은색, 잔여는 회색입니다.</div>';
      
      q('deckReuseQuantities').innerHTML=spliceEnabled?reuseQuantityTable([],recycling.assemblies,steelSource):'';
      q('deckReuseDrawings').innerHTML=spliceEnabled?reuseSourceDrawings(recycling,steelSource,k):'';
      const reusedPosts=recycling.assemblies.filter(a=>a.role==='post').length,sharedPosts=spliceEnabled?0:[...jp.bins,...bp.bins].reduce((n,b)=>n+b.roles.filter(role=>role==='post').length,0),newPosts=postCount-reusedPosts-sharedPosts;
      const count=installation.pieceCount,fix=fast==='screw'?count*Math.ceil(L/600)*2:joists*Math.ceil(W/600)+joists;
      const gaps=layout.segments.flatMap(s=>s.positions.slice(1).map((p,i)=>Math.round((p-s.positions[i])*10)/10)),averageGap=gaps.reduce((a,b)=>a+b,0)/gaps.length;
      const averageRounded=Math.round(averageGap*100)/100,averageLabel=(Math.abs(averageGap-averageRounded)>1e-7?'약 ':'')+averageRounded.toLocaleString('ko-KR',{maximumFractionDigits:2});
      const minGap=Math.min(...gaps),maxGap=Math.max(...gaps);
      const means=layout.segments.map(s=>(s.end-s.start)/(s.positions.length-1)),minMean=Math.min(...means),maxMean=Math.max(...means),precise=n=>Number(n.toFixed(2)).toLocaleString('ko-KR',{maximumFractionDigits:2});
      const equalLabel=joins?(Math.abs(minMean-maxMean)<1e-7?precise(minMean):precise(minMean)+'~'+precise(maxMean)):averageLabel;
      const doubleNote=joins?' · 이중 장선 '+layout.doubleCount+'줄('+joins+'곳 × 2줄, 중심 간격 '+fmt(layout.width)+'mm)':'';
      const metrics={bearerCount:bearers,joistCount:joists,heightValue:fmt(postLength),postCount,postExtraStock:pp.bins.length,steelCount,steel:(steelPlans.reduce((n,p)=>n+p.total,0)/1000).toFixed(2),area:(baseL*baseW*(100+margin)/1e8).toFixed(2),cut:boards.bins.length,fix,fixUnit:'개',spacingPill:'간격 '+fmt(maxJoist)+'mm · '+(fixedJoist?'간격 고정':'균등 배치')};
      Object.entries(metrics).forEach(([id,v])=>text(id,v));text('marginPill','상판 면적 여유 '+fmt(margin)+'%');
      text('bearerLegendSpacing','균등 간격 '+precise(W/(bearers-1))+'mm');
      const along=L/(postsPerBearer-1),across=W/(bearers-1);
      text('postLegendSpacing',postCount?'간격 '+precise(axis==='length'?along:across)+' × '+precise(axis==='length'?across:along)+'mm (길이×폭)':'미설치');
      if(!fixedJoist)text('spacingPill','균등 간격 '+equalLabel+'mm');
      text('heightQuantity','× '+fmt(postCount)+'개');
      text('steelReuseCount',recycling.assemblies.length);text('steelReuseLength',(recycling.recoveredLength/1000).toFixed(2));text('steelSavedStock',recycling.savedCount);
      q('deckReuseSummary').textContent=spliceEnabled?'각관 재단 재활용: 완성 부재 '+recycling.assemblies.length+'개 · 잔재 '+fmt(recycling.recoveredLength)+'mm · 연결 '+recycling.jointCount+'곳 · 원자재 '+recycling.savedCount+'본('+fmt(recycling.savedLength)+'mm) 절감. '+(recycling.limited?'대량 잔재는 탐색 범위 내에서 비교했습니다. ':'')+'최소 사용 가능 길이 '+fmt(minimum)+'mm 이상의 계산 잔재만 사용합니다. 실제 필요 부재 길이 기준이며 이음 보강재와 겹침 여유는 별도입니다.':'각관 재단 재활용: 이어쓰기 해제';
      const lastGap=joistPositions[joistPositions.length-1]-joistPositions[joistPositions.length-2];
      q('deckJoistPlan').textContent=(fixedJoist?'장선 중심 간격 '+fmt(maxJoist)+'mm 고정 · '+(joins?'이음부 사이 구간별 배치':'마지막 구간 '+fmt(lastGap)+'mm'):'장선 균등 배치 치수 '+equalLabel+'mm · '+gaps.length+'구간 · 입력 간격 '+fmt(maxJoist)+'mm 이하'+(minGap!==maxGap?' · 도면 간격 '+fmt(minGap)+'~'+fmt(maxGap)+'mm(0.1mm 단위)':''))+' · 일반 장선 '+regularJoists+'줄'+doubleNote+' · 총 '+joists+'줄'+(joins?' · '+layout.segments.map((s,i)=>(i+1)+'구간 '+fmt(s.start)+'~'+fmt(s.end)+'mm / 간격 '+(fixedJoist?fmt(maxJoist):precise(means[i]))+'mm').join(' · '):'');
      text('deckSteelUsage',usage(steelPlans));text('deckBoardUsage',usage([boards]));
      q('deckPostPlan').textContent=postLength>0?'기둥 '+fmt(postLength)+'mm × '+postCount+'개 · 멍에 '+bearers+'줄 × 줄당 '+postsPerBearer+'개(양 끝 포함). 설치 간격은 멍에 간격 '+fmt(spacing)+'mm 이하로 균등 배치합니다. 기둥 전용 구매 각관 '+pp.bins.length+'본.'+(spliceEnabled?' 잔재로 제작 '+reusedPosts+'개 · 새 원자재로 제작 '+newPosts+'개.':' 공용 원자재에서 기둥 '+sharedPosts+'개 · 기둥 전용 원자재에서 '+newPosts+'개.'):'기둥 높이 0mm · 기둥 재단 없음';
      const byLength=new Map();boards.bins.forEach(b=>byLength.set(b.stock,(byLength.get(b.stock)||0)+1));
      q('boardPlan').innerHTML='<b>상판 자재별 수량</b>'+[...byLength].sort((a,b)=>a[0]-b[0]).map(([s,n])=>'<div class="board-stock-row" data-stock-length="'+s+'" data-quantity="'+n+'"><span>'+deckSwatch(boardSource(s))+' '+boardSource(s).code+' · '+fmt(s)+'mm</span><b>'+n+'본</b></div>').join('')+'<div class="site-status">상판 재단 '+count+'개 · '+rowCount+'행 · 톱날 '+fmt(k)+'mm · 잔여 '+fmt(boards.waste)+'mm<br>'+window.RunLayout.describe(installation)+'<br>프레임 연동 비교 · 상판 '+fmt(boards.total)+'mm + 각관 '+fmt(arrangement.evaluation.total)+'mm · 이음·프레임 검토 후 구매 길이 합계 비교</div>';
      q('cutDiagrams').innerHTML=diagram('각관 재단 · 장선 '+joists+'줄',jp,'#1f7a63',steelSource)+diagram('각관 재단 · 멍에 '+bearers+'줄',bp,'#d86b35',steelSource)+(pp.bins.length?diagram('각관 재단 · 기둥 별도 '+newPosts+'개',pp,'#35564b',steelSource):'')+diagram('상판 재단 · '+rowCount+'행',boards,'#6b7bb5',boardSource)+'<div class="note">공용 재단 조합 비교 · 잔재 단일 재단은 기본 적용 · 잔재 연결은 체크 시에만 적용 · 톱날 '+fmt(k)+'mm/회 · '+(spliceEnabled?'이어쓰기 잔재 조합 비교 적용':jp.exact&&bp.exact&&pp.exact&&boards.exact?'부재별 조합 탐색 완료':'대량 품목은 빠른 조합 비교 적용')+(joins?' · 길이 방향 연결부 '+joins+'곳 포함':'')+'</div>';
      const boardPools=new Map();
      const cutLengths=[...new Set(installation.demand.map(length=>Math.round(length*10)))].sort((a,b)=>a-b),cutColors=new Map(cutLengths.map((length,i)=>[length,R.previewColor(i)]));
      q('deckBoardPreviewLegend').innerHTML=cutLengths.map(length=>'<span class="deck-material-chip" data-cut-length="'+(length/10)+'">'+deckSwatch({color:cutColors.get(length)})+'재단 '+fmt(length/10)+'mm</span>').join('');
      boards.bins.forEach(bin=>bin.used.forEach(length=>{const key=Math.round(length*10);if(!boardPools.has(key))boardPools.set(key,{sources:[],cursor:0});boardPools.get(key).sources.push(boardSource(bin.stock));}));
      const boardSources=installation.rowPieces.map(row=>row.map(length=>{const key=Math.round(length*10),pool=boardPools.get(key),source=pool?.sources[pool.cursor++];if(!source)throw Error('상판 미리보기와 원자재 재단 수량이 일치하지 않습니다.');return{...source,previewColor:cutColors.get(key)};}));
      window.draw?.(L,W,joists,bearers,joins,bw,postCount?postsPerBearer:0,joistPositions,layout.doublePositions,installation,boardSources);
    } catch(e){window.RunLayout.report('deck',e.message);text('marginPill','상판 면적 여유 —');text('heightQuantity','× —개');['spacingPill','bearerLegendSpacing','postLegendSpacing','bearerCount','joistCount','heightValue','steelCount','steel','area','cut','fix','deckSteelUsage','deckBoardUsage','postCount','postExtraStock','steelReuseCount','steelReuseLength','steelSavedStock'].forEach(id=>text(id,'—'));q('boardPlan').innerHTML='';q('deckBoardPreviewLegend').innerHTML='';q('steelPlan').innerHTML='';q('deckPostPlan').textContent='';q('deckReuseSummary').textContent='';q('deckReuseQuantities').innerHTML='';q('deckReuseDrawings').innerHTML='';q('deckJoistPlan').textContent='';q('diagram').innerHTML='';q('deckMaterialLegend').innerHTML=q('deckMaterialQuantities').innerHTML='';notice('cutDiagrams',e.message);}
  }
  function cutting(){
    try {
      const stocks=new Map(),items=new Map(),k=kerf('cutSawKerf');
      q('stockRows').querySelectorAll('.cut-input-row').forEach(r=>{const m=r.querySelector('.stock-material').value,s=Number(r.querySelector('.stock-length').value);if(!Number.isFinite(s)||s<=0)throw Error('원자재 길이를 입력해주세요.');if(!stocks.has(m))stocks.set(m,[]);stocks.get(m).push(s);});
      q('cutRows').querySelectorAll('.cut-input-row').forEach(r=>{const m=r.querySelector('.cut-material').value,n=Number(r.querySelector('.cut-length').value),qty=Number(r.querySelector('.cut-quantity').value);if(!Number.isFinite(n)||n<=0||!Number.isInteger(qty)||qty<=0||qty>2000)throw Error('재단 길이와 수량(1~2,000)을 확인해주세요.');if(!items.has(m))items.set(m,[]);if(items.get(m).length+qty>2000)throw Error('자재별 수량은 2,000개 이하로 입력해주세요.');items.get(m).push(...Array(qty).fill(n));});
      if(!items.size)throw Error('원자재 목록과 재단 품목을 입력해주세요.');
      const plans=[...items].map(([m,values])=>{if(!stocks.has(m))throw Error(m+' 원자재를 추가해주세요.');const p=E.pack(stocks.get(m),values,k);return {...p,material:m,bins:p.bins.map(b=>({...b,material:m}))};});
      const bins=plans.flatMap(p=>p.bins),groups=E.groups(bins);
      text('cutUsage',usage(plans));
      const report=R.create([...stocks].flatMap(([material,lengths])=>lengths.map(length=>({material,length}))),bins),source=b=>report.lookup(b.material,b.stock);
      q('cutStockSummary').innerHTML=R.summary(report);q('cutMaterialLegend').innerHTML=R.legend(report);q('cutMaterialQuantities').innerHTML=R.table(report);
      text('cutStockCount',bins.length);text('cutNeedTotal',(bins.reduce((s,b)=>s+b.used.reduce((a,x)=>a+x,0),0)/1000).toFixed(2));text('cutWasteTotal',fmt(plans.reduce((s,p)=>s+p.waste,0)));text('cutMaterialLabel','원자재 조합 최적화 · 톱날 '+fmt(k)+'mm');
      q('cutTableWrap').innerHTML='<div class="note">원자재 총길이 최소, 같으면 본수 최소 · '+(plans.every(p=>p.exact)?'조합 탐색 완료':'대량 품목 빠른 조합 비교')+' · 잔여와 톱날 손실을 별도 표시합니다.</div><table class="cut-table"><thead><tr><th>자재</th><th>원자재</th><th>재단 구성</th><th>수량</th><th>톱날 손실/본</th><th>잔여/본</th></tr></thead><tbody>'+groups.map(b=>'<tr data-stock-code="'+source(b).code+'"><td>'+R.swatch(source(b))+' '+source(b).code+' · '+escape(b.material)+'</td><td>'+fmt(b.stock)+'mm</td><td>'+partsText(b.used)+'</td><td>'+b.qty+'본</td><td>'+fmt(b.loss)+'mm</td><td>'+fmt(b.left)+'mm</td></tr>').join('')+'</tbody></table>';
      q('standaloneBars').innerHTML=plans.map(p=>diagram(escape(p.material),p,'#1f7a63',n=>report.lookup(p.material,n))).join('');
    }catch(e){['cutStockCount','cutNeedTotal','cutWasteTotal','cutUsage'].forEach(id=>text(id,'—'));q('standaloneBars').innerHTML='';q('cutStockSummary').innerHTML='';q('cutMaterialLegend').innerHTML=q('cutMaterialQuantities').innerHTML='';notice('cutTableWrap',e.message);}
  }
  // Calculation runs only through the explicit buttons.
  window.calc=()=>{};window.cutCalc=()=>{};
  q('calculate').onclick=deck;q('cutCalculate').onclick=cutting;
})();


(() => {
  'use strict';
  const q=id=>document.getElementById(id),fields=['louverLength','louverWidth'];
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>Number(n).toLocaleString('ko-KR',{maximumFractionDigits:1}),sqm=n=>(n/1e6).toFixed(3);
  const stockKey=(kind,length,width)=>JSON.stringify([kind,Number(length),Number(width)]);
  const stockColor=row=>row.code==='S2'?'#D2AE7C':window.StockReport.color(Number(row.code.slice(1))-1);
  const swatch=row=>'<i class="louver-material-swatch" aria-hidden="true" style="background:'+stockColor(row)+'"></i>';
  let axis='length';
  const setAxis=value=>{axis=value==='width'?'width':'length';document.querySelectorAll('[data-louver-axis]').forEach(b=>b.classList.toggle('active',b.dataset.louverAxis===axis));};
  document.querySelectorAll('[data-louver-axis]').forEach(b=>b.onclick=()=>setAxis(b.dataset.louverAxis));
  function addStock(data={},editor=false){
    const row=document.createElement('div');if(data.catalog)row.dataset.catalog=JSON.stringify(data.catalog);row.className='louver-stock-row';
    for(const [key,label] of [['kind','원자재 종류'],['length','원자재 길이 mm'],['width','원자재 유효 폭 mm']]){const input=document.createElement('input');input.className='louver-stock-'+key;input.type=key==='kind'?'text':'number';input.placeholder=label;input.setAttribute('aria-label',label);if(key!=='kind'){input.min='0.1';input.step='0.1';input.inputMode='decimal';}input.value=data[key]??(key==='kind'?'루바':'');row.appendChild(input);}
    const remove=document.createElement('button');remove.type='button';remove.className='cut-remove';remove.textContent='×';remove.setAttribute('aria-label','루바 원자재 삭제');remove.onclick=()=>row.remove();row.appendChild(remove);
    q('louverStockRows').appendChild(row);if(!editor)window.MaterialLists.compact(row);return row;
  }
  window.MaterialLists.bind('louverStockRows','louverAddStock',(data,editor)=>addStock(data,editor));
  window.currentLouverData=()=>({...Object.fromEntries(fields.map(id=>[id,q(id).value])),axis,runLayout:window.RunLayout.read('louver'),kerf:q('louverSawKerf').value,marginPercent:q('louverMarginPercent').value,stocks:[...q('louverStockRows').children].map(r=>({catalog:JSON.parse(r.dataset.catalog||'null'),kind:r.querySelector('.louver-stock-kind').value,length:r.querySelector('.louver-stock-length').value,width:r.querySelector('.louver-stock-width').value}))});
  window.clearLouverResults=(value='—')=>{window.MarginAllowance?.clear('louver');['louverSiteArea','louverBoardArea','louverAreaMinimum','louverResultCount','louverPurchaseArea','louverWasteArea','louverUsage'].forEach(id=>q(id).textContent=value);window.StockReport.displayUtilization(q('louverUsage'),value);q('louverDiagram').innerHTML='';q('louverCutDiagrams').innerHTML='';q('louverMaterialLegend').innerHTML='';q('louverMaterialQuantities').innerHTML='';q('louverDetails').textContent='';q('louverStockUsed').textContent='';q('louverStockSummary').innerHTML='';q('louverStockComparison').innerHTML='';q('louverDirection').textContent='시공 방향 선택';};
  window.applyLouverData=data=>{window.MaterialLists.reset('louverStockRows');fields.forEach(id=>q(id).value=data?.[id]??'');q('louverStockRows').replaceChildren();let stocks=data?.stocks;if(!stocks&&(data?.louverBoardLength||data?.louverBoardWidth))stocks=[{kind:'루바',length:data.louverBoardLength,width:data.louverBoardWidth}];(stocks||[]).forEach(s=>addStock(s));setAxis(data?.axis);window.RunLayout.restore('louver',data?.runLayout);q('louverMarginPercent').value=data?.marginPercent??'0';q('louverSawKerf').value=data?.kerf??'';window.clearLouverResults();};
  function draw(p,materials){
    const scale=Math.min(560/p.length,220/p.width),w=p.length*scale,h=p.width*scale,x=(700-w)/2,y=55+(220-h)/2;
    const pw=p.axis==='length'?w:p.boardWidth*scale,ph=p.axis==='length'?p.boardWidth*scale:h;
    const pools=new Map();p.bins.forEach(b=>b.used.forEach(length=>{if(!pools.has(length))pools.set(length,{stocks:[],cursor:0});pools.get(length).stocks.push(b.stock);}));
    let offset=0,rects='',colored='';
    for(const length of p.rowPieces){const xx=p.axis==='length'?offset:0,yy=p.axis==='length'?0:offset,ww=p.axis==='length'?length*scale:pw,hh=p.axis==='length'?ph:length*scale;rects+='<rect x="'+xx+'" y="'+yy+'" width="'+ww+'" height="'+hh+'" fill="#d6b28c" stroke="#755033" stroke-width="1"/>';offset+=length*scale;}
    for(let row=0;row<p.rows;row++){let along=0;for(const length of p.installation.rowPieces[row]){
      const pool=pools.get(length),sourceLength=pool.stocks[pool.cursor++],material=materials.get(stockKey(p.kind,sourceLength,p.boardWidth));
      const xx=x+(p.axis==='length'?along:row*p.boardWidth*scale),yy=y+(p.axis==='length'?row*p.boardWidth*scale:along),ww=(p.axis==='length'?length:p.boardWidth)*scale,hh=(p.axis==='length'?p.boardWidth:length)*scale;
      colored+='<rect data-install-row="'+row+'" data-cut-length="'+length+'" data-start="'+(along/scale)+'" data-stock-code="'+material.code+'" x="'+xx+'" y="'+yy+'" width="'+ww+'" height="'+hh+'" fill="'+stockColor(material)+'" stroke="#ffffff" stroke-width=".7"><title>'+material.code+' · '+esc(material.kind)+' · 원자재 '+fmt(sourceLength)+' × '+fmt(p.boardWidth)+'mm · 재단 '+fmt(length)+'mm</title></rect>';along+=length*scale;
    }}
    q('louverDiagram').innerHTML='<defs><pattern id="louverGrid" x="'+x+'" y="'+y+'" width="'+pw+'" height="'+ph+'" patternUnits="userSpaceOnUse">'+rects+'</pattern><clipPath id="louverAreaClip"><rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'"/></clipPath></defs><rect width="700" height="330" rx="10" fill="#f7faf7"/><text x="350" y="25" text-anchor="middle" fill="#35564b" font-size="13">시공 길이 '+fmt(p.length)+'mm × 시공 폭 '+fmt(p.width)+'mm</text><rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" fill="url(#louverGrid)" stroke="#755033"/><g clip-path="url(#louverAreaClip)">'+colored+'</g><text x="350" y="305" text-anchor="middle" fill="#35564b" font-size="12">'+fmt(p.rows)+'행 · '+fmt(p.pieceCount)+'조각 · 원자재 '+fmt(p.count)+'장</text>';
  }
  q('louverCalculate').onclick=()=>{
    window.RunLayout.report('louver');
    try{
      const data=window.currentLouverData(),result=window.LouverEngine.optimize({length:data.louverLength,width:data.louverWidth,axis,stocks:data.stocks,runLayout:data.runLayout,kerf:data.kerf}),p=result.best;
      const values={louverSiteArea:sqm(p.area),louverBoardArea:sqm(p.boardArea),louverAreaMinimum:fmt(p.areaMinimum),louverResultCount:fmt(p.count),louverPurchaseArea:sqm(p.purchasedArea),louverWasteArea:sqm(p.wasteArea),louverDirection:(p.axis==='length'?'길이':'폭')+' 방향'};
      Object.entries(values).forEach(([id,value])=>q(id).textContent=value);
      window.StockReport.displayUtilization(q('louverUsage'),window.StockReport.utilization(p.area,p.purchasedArea));
      const summary=window.LouverEngine.materialSummary(data.stocks,p),materials=new Map(summary.map(s=>[stockKey(s.kind,s.length,s.width),s]));
      q('louverStockSummary').innerHTML=window.StockReport.summary({mode:'sheet',rows:summary.map(s=>({...s,material:s.kind,color:stockColor(s)}))});
      q('louverMaterialLegend').innerHTML=summary.filter(s=>s.quantity).map(s=>'<span class="louver-material-chip">'+swatch(s)+s.code+' · '+esc(s.kind)+' '+fmt(s.length)+' × '+fmt(s.width)+'mm</span>').join('');
      q('louverMaterialQuantities').innerHTML='<table class="cut-table"><thead><tr><th>색상·번호</th><th>자재 종류</th><th>길이 × 폭</th><th>원자재 수량</th><th>재단품 수량</th><th>길이 잔여 합계</th><th>톱날 손실 합계</th></tr></thead><tbody>'+summary.map(s=>'<tr data-stock-code="'+s.code+'" data-quantity="'+s.quantity+'"'+(!s.quantity?' class="louver-unused"':'')+'><td>'+swatch(s)+' '+s.code+'</td><td>'+esc(s.kind)+'</td><td>'+fmt(s.length)+' × '+fmt(s.width)+'mm</td><td>'+fmt(s.quantity)+'장'+(!s.quantity?' · 미사용':'')+'</td><td>'+fmt(s.pieceCount)+'조각</td><td>'+fmt(s.remainingLength)+'mm</td><td>'+fmt(s.lossLength)+'mm</td></tr>').join('')+'</tbody><tfoot><tr><td colspan="3">합계</td><td>'+fmt(p.count)+'장</td><td>'+fmt(p.pieceCount)+'조각</td><td>'+fmt(p.lengthWaste)+'mm</td><td>'+fmt(p.lengthLoss)+'mm</td></tr></tfoot></table>';
      const usedMaterials=summary.filter(s=>s.quantity>0);
      q('louverStockUsed').textContent='자동 선정: '+p.kind+' · 폭 '+fmt(p.boardWidth)+'mm · '+usedMaterials.map(s=>fmt(s.length)+'mm × '+s.quantity+'장').join(' / ');
      q('louverCutDiagrams').innerHTML=p.cuts.map(g=>{const material=materials.get(stockKey(p.kind,g.stock,p.boardWidth));return '<div class="diagram-group" data-stock-code="'+material.code+'"><div class="cut-label"><b>'+swatch(material)+' '+material.code+' · '+esc(p.kind)+' · 원자재 '+fmt(g.stock)+'mm · × '+fmt(g.qty)+'장</b><span>재단 '+g.used.map(n=>fmt(n)+'mm').join(' + ')+' · 톱날 손실 '+fmt(g.loss)+'mm · 잔여 '+fmt(g.left)+'mm/장</span></div><div class="bar-track louver-cut-track">'+g.used.map(n=>'<span class="louver-cut-piece" style="background:'+stockColor(material)+';flex:0 0 '+(n/g.stock*100)+'%">'+fmt(n)+'mm</span>').join('')+(g.loss?'<span class="louver-cut-loss" style="background:#B54747;color:#fff;flex:0 0 '+(g.loss/g.stock*100)+'%" title="톱날 손실 '+fmt(g.loss)+'mm">톱날</span>':'')+(g.left?'<span class="louver-cut-remainder" style="flex:0 0 '+(g.left/g.stock*100)+'%">잔여 '+fmt(g.left)+'mm</span>':'')+'</div></div>';}).join('')+'<div class="site-status">총 재단품 '+fmt(p.pieceCount)+'조각 · 원자재 '+fmt(p.count)+'장. 같은 종류·폭의 원자재에서 길이를 조합하고 잔재를 재사용합니다. 톱날 '+fmt(p.kerf)+'mm/회 · 길이 재단 손실 합계 '+fmt(p.lengthLoss)+'mm. '+(p.lastWidth<p.boardWidth?'마지막 행은 폭 '+fmt(p.lastWidth)+'mm로 별도 폭 재단합니다.':'별도 폭 재단은 없습니다.')+'</div>';
      q('louverStockComparison').innerHTML='<h3>종류·폭별 최적화 비교</h3><table class="cut-table"><thead><tr><th>종류 · 폭</th><th>후보 길이</th><th>필요 장수</th><th>구매 면적</th><th>잔여 면적</th></tr></thead><tbody>'+result.comparisons.map(r=>'<tr'+(r===p?' class="louver-selected"':'')+'><td>'+esc(r.kind)+' · '+fmt(r.boardWidth)+'mm'+(r===p?' · 자동 선정':'')+'</td><td>'+r.options.map(n=>fmt(n)+'mm').join(' / ')+'</td><td>'+fmt(r.count)+'장</td><td>'+sqm(r.purchasedArea)+'㎡</td><td>'+sqm(r.wasteArea)+'㎡</td></tr>').join('')+'</tbody></table>';
      q('louverDetails').textContent=fmt(p.rows)+'행 · '+window.RunLayout.describe(p.installation)+' = 재단품 '+fmt(p.pieceCount)+'조각. 목록 전체를 비교하고 같은 종류·폭끼리 길이를 조합합니다. 자동 배치는 같은 종류·폭에서 이음을 먼저 줄이고, 종류·폭 대안은 구매 면적과 장수를 비교합니다. 여러 재단 조합을 비교하는 방식으로 절대 최솟값을 보장하지 않습니다.'+(result.skippedGroups?' '+result.skippedGroups+'개 종류·폭 그룹은 입력 조건에 맞지 않아 비교에서 제외했습니다.':'');
      draw(p,materials);
    }catch(e){window.clearLouverResults();window.RunLayout.report('louver',e.message);q('louverDetails').textContent=e.message;}
  };
  q('louverSaveSite').onclick=()=>{q('siteName').value=q('louverSiteName').value;q('saveSite').click();};
  q('louverLoadSite').onclick=()=>{q('siteList').value=q('louverSiteList').value;q('loadSite').click();};
  q('louverSiteAdd').onclick=()=>{q('louverSiteName').value='';q('louverSiteList').value='';q('louverSiteName').focus();q('louverSaveStatus').textContent='새 현장명을 입력하고 저장해주세요.';};
  q('louverSiteDelete').onclick=()=>{q('siteList').value=q('louverSiteList').value;q('siteName').value=q('louverSiteName').value;q('siteNameDelete').click();};
  q('louverPrint').onclick=window.printReport;window.clearLouverResults();
})();


(function(root){
  'use strict';
  function calculate(input){
    const read=(key,label)=>{const n=Math.round(Number(input[key])*10);if(!Number.isSafeInteger(n)||n<1||n>10000000)throw Error(label+'은(는) 0.1~1,000,000mm로 입력해주세요.');return n;};
    const L=read('length','시공 길이'),W=read('width','시공 폭'),bl=read('boardLength','루바 길이'),bw=read('boardWidth','루바 폭');
    const axis=input.axis==='width'?'width':'length',run=axis==='length'?L:W,cross=axis==='length'?W:L;
    const perRow=Math.ceil(run/bl),rows=Math.ceil(cross/bw),count=perRow*rows,area=L*W/100,boardArea=bl*bw/100,purchasedArea=count*boardArea;
    return {length:L/10,width:W/10,boardLength:bl/10,boardWidth:bw/10,axis,perRow,rows,count,area,boardArea,purchasedArea,wasteArea:purchasedArea-area,areaMinimum:Math.ceil((L*W)/(bl*bw)),lastLength:(run-(perRow-1)*bl)/10,lastWidth:(cross-(rows-1)*bw)/10,columns:axis==='length'?perRow:rows,gridRows:axis==='length'?rows:perRow,cellLength:(axis==='length'?bl:bw)/10,cellWidth:(axis==='length'?bw:bl)/10};
  }
  function lengthCuts(plan){
    const fullPerRow=plan.lastLength===plan.boardLength?plan.perRow:plan.perRow-1,groups=[];
    if(fullPerRow>0)groups.push({stockLength:plan.boardLength,cutLength:plan.boardLength,remaining:0,quantity:fullPerRow*plan.rows});
    if(plan.lastLength<plan.boardLength)groups.push({stockLength:plan.boardLength,cutLength:plan.lastLength,remaining:Math.round((plan.boardLength-plan.lastLength)*10)/10,quantity:plan.rows});
    return groups;
  }
  function optimize(input){
    const packer=typeof module!=='undefined'&&module.exports?require('./cutting-engine'):root.CuttingEngine;
    const layoutEngine=typeof module!=='undefined'&&module.exports?require('./run-layout'):root.RunLayout;
    const rawKerf=Number(input.kerf??0);
    if(!Number.isFinite(rawKerf)||rawKerf<0||rawKerf>1000000)throw Error('톱날 두께는 0~1,000,000mm로 입력해주세요.');
    const kerf=Math.round(rawKerf*10)/10;
    const stocks=input.stocks||[];if(!stocks.length)throw Error('원자재를 추가해주세요.');if(stocks.length>30)throw Error('원자재 규격은 30개 이하로 입력해주세요.');
    const groups=new Map();let base;
    stocks.forEach((stock,i)=>{
      const kind=String(stock.kind||'').trim();if(!kind)throw Error((i+1)+'번째 원자재 종류를 입력해주세요.');
      let p;try{p=calculate({...input,boardLength:stock.length,boardWidth:stock.width});}catch(e){throw Error((i+1)+'번째 원자재: '+e.message);}
      base=base||p;const key=JSON.stringify([kind,p.boardWidth]);if(!groups.has(key))groups.set(key,{kind,width:p.boardWidth,lengths:new Set()});groups.get(key).lengths.add(p.boardLength);
    });
    const run=Math.round((base.axis==='length'?base.length:base.width)*10),cross=Math.round((base.axis==='length'?base.width:base.length)*10);
    layoutEngine.manual(run/10,input.runLayout||{}); // Validate explicit dimensions/count before comparing stock groups.
    const compare=(a,b)=>a.purchasedArea-b.purchasedArea||a.count-b.count||a.perRow-b.perRow;
    const comparisons=[];
    for(const group of groups.values()){
      const options=[...group.lengths].sort((a,b)=>a-b),rows=Math.ceil(cross/Math.round(group.width*10));let best=null;
      try{
        const {parts,installation,packed}=layoutEngine.optimize(run/10,options,rows,input.runLayout||{},kerf),purchasedArea=packed.total*group.width;
        best={...base,kind:group.kind,boardWidth:group.width,boardLength:Math.max(...options),rowPieces:parts,installation,rows,perRow:parts.length,count:packed.bins.length,pieceCount:installation.pieceCount,purchasedArea,wasteArea:purchasedArea-base.area,boardArea:purchasedArea/packed.bins.length,areaMinimum:Math.ceil(base.area/(Math.max(...options)*group.width)),lastLength:parts[parts.length-1],lastWidth:(cross-(rows-1)*Math.round(group.width*10))/10,bins:packed.bins,cuts:packer.groups(packed.bins),lengthWaste:packed.waste,lengthLoss:packed.loss,kerf,options};
      }catch(error){/* Another kind/width group may satisfy the requested partition. */}
      if(best)comparisons.push(best);
    }
    if(!comparisons.length)throw Error('입력한 분할 치수를 재단할 원자재가 없거나 2,000조각을 초과합니다. 원자재 길이·분할 치수·톱날 두께를 확인해주세요.');
    comparisons.sort(compare);
    return {best:comparisons[0],comparisons,skippedGroups:groups.size-comparisons.length};
  }
  function materialSummary(stocks,plan){
    const key=(kind,length,width)=>JSON.stringify([String(kind).trim(),Math.round(Number(length)*10)/10,Math.round(Number(width)*10)/10]),map=new Map();
    stocks.forEach(s=>{const k=key(s.kind,s.length,s.width);if(!map.has(k))map.set(k,{kind:String(s.kind).trim(),length:Math.round(Number(s.length)*10)/10,width:Math.round(Number(s.width)*10)/10,quantity:0,pieceCount:0,remainingLength:0,lossLength:0});});
    plan.bins.forEach(b=>{const row=map.get(key(plan.kind,b.stock,plan.boardWidth));if(!row)throw Error('원자재 수량 집계 규격을 확인해주세요.');row.quantity++;row.pieceCount+=b.used.length;row.remainingLength+=b.left;row.lossLength+=b.loss;});
    return [...map.values()].sort((a,b)=>a.kind.localeCompare(b.kind,'ko')||a.width-b.width||a.length-b.length).map((row,i)=>({...row,remainingLength:Math.round(row.remainingLength*10)/10,lossLength:Math.round(row.lossLength*10)/10,code:'S'+(i+1)}));
  }
  const api={calculate,lengthCuts,optimize,materialSummary};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.LouverEngine=api;
})(typeof window==='undefined'?globalThis:window);

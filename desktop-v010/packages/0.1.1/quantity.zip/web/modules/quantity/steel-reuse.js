
/* Replace entire purchased bars with cuts from other bars' actual residuals.
   Donor bars cannot later be removed, so source references never form cycles. */
(function(root){
  'use strict';
  const unit=n=>Math.round(Number(n)*10),sum=a=>a.reduce((n,x)=>n+x,0);
  // Internal arrays are append-only between clones. Cache their integer net
  // length rather than rescanning every existing cut for each donor trial.
  const netTotals=new WeakMap();
  function netOf(used){let entry=netTotals.get(used);if(!entry||entry.count!==used.length){entry={count:used.length,total:sum(used.map(unit))};netTotals.set(used,entry);}return entry.total;}
  function appendCut(b,length,role){const total=netOf(b.used)+unit(length);b.used.push(length);b.roles.push(role);netTotals.set(b.used,{count:b.used.length,total});}
  function measure(b,extra,k){
    const stock=unit(b.stock),net=netOf(b.used)+extra,n=b.used.length+1;
    const loss=net+(n-1)*k===stock?(n-1)*k:n*k;
    return{fits:net+loss<=stock,left:stock-net-loss,loss};
  }
  function optimize(input,kerf=0){
    const k=unit(kerf);if(!Number.isSafeInteger(k)||!Number.isFinite(Number(kerf))||Number(kerf)<0)throw Error('톱날 두께를 확인해주세요.');
    const copy=b=>({...b,used:b.used.slice(),roles:b.roles.slice()});
    let bins=input.map((b,i)=>({...b,id:'T'+(i+1),used:b.used.slice(),roles:b.used.map((_,j)=>b.roles?.[j]||b.owner||'steel')}));
    for(const b of bins)if(!Number.isSafeInteger(unit(b.stock))||unit(b.stock)<=0||b.used.some(x=>!Number.isSafeInteger(unit(x))||unit(x)<=0)||![b.left,b.loss].every(x=>Number.isSafeInteger(unit(x))&&unit(x)>=0)||Math.abs(unit(b.stock)-sum(b.used.map(unit))-unit(b.loss)-unit(b.left))>0)throw Error('각관 잔재의 길이 합계를 확인해주세요.');
    const candidates=bins.slice().sort((a,b)=>sum(a.used)/a.stock-sum(b.used)/b.stock||b.stock-a.stock),locked=new Set(),assemblies=[];
    let work=0,limited=false;
    const spend=()=>{if(++work>400000)throw Error('reuse-budget');};
    try{for(const candidate of candidates){
      spend();if(locked.has(candidate.id)||!bins.some(b=>b.id===candidate.id))continue;
      const others=bins.filter(b=>b.id!==candidate.id);
      if(sum(others.map(b=>unit(b.left)))<sum(candidate.used.map(unit)))continue;
      const trial=others.map(copy),assembled=[];let valid=true;
      const jobs=candidate.used.map((length,i)=>({length:unit(length),role:candidate.roles[i]})).sort((a,b)=>b.length-a.length);
      for(const job of jobs){
        const parts=[];let remaining=job.length;
        while(remaining>0){
          let donor=null,take=0,next=null;
          // Prefer one intact offcut whenever it can finish the target.
          for(const b of trial){spend();if(unit(b.left)<remaining)continue;const u=measure(b,remaining,k);if(u.fits&&(!next||u.left<next.left)){donor=b;take=remaining;next=u;}}
          if(!donor)for(const b of trial){spend();const left=unit(b.left),piece=left<=remaining?left:left-k;if(piece<=0||piece>remaining)continue;const u=measure(b,piece,k);if(u.fits&&piece>take){donor=b;take=piece;next=u;}}
          if(!donor){valid=false;break;}
          appendCut(donor,take/10,'reuse-'+job.role);donor.left=next.left/10;donor.loss=next.loss/10;
          parts.push({source:donor.id,stock:donor.stock,length:take/10});remaining-=take;
        }
        if(!valid)break;
        assembled.push({id:'R'+(assemblies.length+assembled.length+1),role:job.role,length:job.length/10,parts});
      }
      if(!valid)continue;
      bins=trial;for(const a of assembled){assemblies.push(a);for(const p of a.parts)locked.add(p.source);}
    }}catch(e){if(e.message!=='reuse-budget')throw e;limited=true;}
    return{bins,assemblies,limited,originalCount:input.length,savedCount:input.length-bins.length,recoveredLength:sum(assemblies.map(a=>a.length)),reusedSegments:sum(assemblies.map(a=>a.parts.length)),jointCount:sum(assemblies.map(a=>a.parts.length-1)),savedLength:sum(input.map(b=>b.stock))-sum(bins.map(b=>b.stock))};
  }
  // Replace complete required members, not nominal purchased-bar lengths.
  function fromNeeds(input,needs,kerf=0,minimum=0,stockOptions=null){
    const k=unit(kerf),min=unit(minimum);
    if(![k,min].every(n=>Number.isSafeInteger(n)&&n>=0)||![kerf,minimum].every(n=>Number.isFinite(Number(n))&&Number(n)>=0))throw Error('톱날 두께와 잔재 최소 사용 길이를 확인해주세요.');
    const jobs=new Map(needs.map(j=>[j.id,j]));
    if(jobs.size!==needs.length)throw Error('필요 부재 번호가 중복되었습니다.');
    let bins=input.map((b,i)=>({...b,id:'T'+(i+1),used:b.used.slice(),roles:b.roles.slice(),jobIds:b.jobIds.slice()}));
    const clone=b=>({...b,used:b.used.slice(),roles:b.roles.slice(),jobIds:b.jobIds.slice()});
    const recalc=b=>{const net=netOf(b.used),n=b.used.length,stock=unit(b.stock);const loss=n?(net+(n-1)*k===stock?(n-1)*k:n*k):0;b.loss=loss/10;b.left=(stock-net-loss)/10;};
    const requiredTotals=new Map();
    for(const b of bins){
      if(b.used.length!==b.roles.length||b.used.length!==b.jobIds.length||!Number.isSafeInteger(unit(b.stock))||b.stock<=0||b.used.some(x=>!Number.isSafeInteger(unit(x))||x<=0)||b.jobIds.some(id=>!jobs.has(id)))throw Error('필요 부재 재단 정보를 확인해주세요.');
      recalc(b);if(b.left<0)throw Error('원자재 길이를 초과한 재단입니다.');
      b.used.forEach((length,i)=>{const id=b.jobIds[i];if(b.roles[i]!==jobs.get(id).role)throw Error('필요 부재 용도를 확인해주세요.');requiredTotals.set(id,(requiredTotals.get(id)||0)+unit(length));});
    }
    for(const j of needs)if(!Number.isSafeInteger(unit(j.length))||j.length<=0||requiredTotals.get(j.id)!==unit(j.length))throw Error('필요 부재 길이 합계를 확인해주세요.');
    const candidates=bins.slice().sort((a,b)=>sum(a.used)/a.stock-sum(b.used)/b.stock||b.stock-a.stock),assemblies=[],done=new Set();let work=0,limited=false;
    const spend=()=>{if(++work>400000)throw Error('reuse-budget');};
    function attempt(ids,partialPost=false){
      spend();ids=new Set([...ids].filter(id=>id&&!done.has(id)));if(!ids.size)return;
      const sources=new Set(bins.filter(b=>b.jobIds.some(id=>ids.has(id))).map(b=>b.id));
      const trial=bins.map(clone);for(const b of trial){const keep=b.used.map((_,i)=>i).filter(i=>!ids.has(b.jobIds[i]));b.used=keep.map(i=>b.used[i]);b.roles=keep.map(i=>b.roles[i]);b.jobIds=keep.map(i=>b.jobIds[i]);recalc(b);}
      const retained=trial.filter(b=>b.used.length),assembled=[];let valid=true;
      const targets=[...ids].map(id=>jobs.get(id)).sort((a,b)=>b.length-a.length);
      const eligible=b=>!sources.has(b.id)&&(!partialPost||b.owner!=='post')&&unit(b.left)>=min;
      if(sum(retained.filter(eligible).map(b=>unit(b.left)))<sum(targets.map(j=>unit(j.length))))return;
      for(const job of targets){
        let remaining=unit(job.length);const parts=[];
        while(remaining>0){
          let donor=null,take=0,next=null;
          for(const b of retained){spend();if(!eligible(b)||unit(b.left)<remaining)continue;const u=measure(b,remaining,k);if(u.fits&&(!next||u.left<next.left)){donor=b;take=remaining;next=u;}}
          if(!donor)for(const b of retained){spend();if(!eligible(b))continue;const left=unit(b.left),piece=left<=remaining?left:left-k;if(piece<=0||piece>remaining)continue;const u=measure(b,piece,k);if(u.fits&&piece>take){donor=b;take=piece;next=u;}}
          if(!donor){valid=false;break;}
          appendCut(donor,take/10,'reuse-'+job.role);donor.jobIds.push(null);donor.left=next.left/10;donor.loss=next.loss/10;parts.push({source:donor.id,stock:donor.stock,length:take/10});remaining-=take;
        }
        if(!valid)break;assembled.push({id:'R'+(assemblies.length+assembled.length+1),jobId:job.id,role:job.role,length:job.length,parts});
      }
      const difference=sum(retained.map(b=>unit(b.stock)))-sum(bins.map(b=>unit(b.stock)));
      if(!valid||difference>0||(!partialPost&&difference===0))return;
      bins=retained;assemblies.push(...assembled);ids.forEach(id=>done.add(id));
    }
    try{
      // Columns consume eligible frame offcuts individually, even if only some
      // columns fit and no complete purchased bar can yet be eliminated.
      for(const job of needs.filter(j=>j.role==='post').sort((a,b)=>b.length-a.length))attempt([job.id],true);
      if(stockOptions){
        const postBins=bins.filter(b=>b.owner==='post'),queues=new Map(),pieces=[];
        for(const b of postBins)b.used.forEach((length,i)=>{pieces.push(length);if(!queues.has(length))queues.set(length,[]);queues.get(length).push(b.jobIds[i]);});
        const engine=typeof module!=='undefined'&&module.exports?require('./cutting-engine'):root.CuttingEngine;
        const packed=engine.pack(stockOptions,pieces,kerf).bins.map((b,i)=>({...b,id:'P'+(i+1),owner:'post',roles:b.used.map(()=>'post'),jobIds:b.used.map(n=>queues.get(n).shift())}));
        if(sum(packed.map(b=>unit(b.stock)))<=sum(postBins.map(b=>unit(b.stock))))bins=bins.filter(b=>b.owner!=='post').concat(packed);
      }
      for(const candidate of candidates)attempt(candidate.jobIds);
    }catch(e){if(e.message!=='reuse-budget')throw e;limited=true;}
    return{bins,assemblies,limited,originalCount:input.length,savedCount:input.length-bins.length,recoveredLength:sum(assemblies.map(a=>a.length)),reusedSegments:sum(assemblies.map(a=>a.parts.length)),jointCount:sum(assemblies.map(a=>a.parts.length-1)),savedLength:sum(input.map(b=>b.stock))-sum(bins.map(b=>b.stock))};
  }
  const api={optimize,fromNeeds};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.SteelReuse=api;
})(typeof window==='undefined'?globalThis:window);

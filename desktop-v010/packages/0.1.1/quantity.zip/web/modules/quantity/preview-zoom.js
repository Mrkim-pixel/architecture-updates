
/* Shared preview controls: zoom changes only the drawing, never the calculation. */
(() => {
  'use strict';
  for (const id of ['diagram', 'louverDiagram']) {
    const svg = document.getElementById(id);
    if (!svg) continue;
    const toolbar = document.createElement('div');
    toolbar.className = 'preview-zoom-toolbar';
    toolbar.innerHTML = '<button type="button" data-zoom="out" aria-label="미리보기 축소">−</button><output aria-live="polite">100%</output><button type="button" data-zoom="in" aria-label="미리보기 확대">＋</button><button type="button" data-zoom="reset">원래 크기</button>';
    const viewport = document.createElement('div');
    viewport.className = 'preview-zoom-viewport';
    viewport.tabIndex = 0;
    viewport.setAttribute('aria-label', '배치 미리보기 · 확대 후 밀어서 이동');
    const parent = svg.parentNode;
    parent.insertBefore(toolbar, svg);
    parent.insertBefore(viewport, svg);
    svg.remove();
    viewport.appendChild(svg);
    let scale = 1;
    function update(value) {
      scale = Math.max(0.5, Math.min(3, value));
      svg.style.setProperty('--preview-scale', scale);
      svg.style.width = (scale * 100) + '%';
      svg.style.maxWidth = 'none';
      svg.style.height = 'auto';
      toolbar.querySelector('output').textContent = Math.round(scale * 100) + '%';
      toolbar.querySelector('[data-zoom="out"]').disabled = scale === 0.5;
      toolbar.querySelector('[data-zoom="in"]').disabled = scale === 3;
      if (scale === 1) { viewport.scrollLeft = 0; viewport.scrollTop = 0; }
    }
    toolbar.querySelector('[data-zoom="out"]').onclick = () => update(scale - 0.25);
    toolbar.querySelector('[data-zoom="in"]').onclick = () => update(scale + 0.25);
    toolbar.querySelector('[data-zoom="reset"]').onclick = () => update(1);
    update(1);
  }
})();

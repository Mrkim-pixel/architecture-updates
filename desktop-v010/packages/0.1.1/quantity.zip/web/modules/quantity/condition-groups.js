
/* Group existing controls after tool setup; moving nodes preserves their handlers. */
(() => {
  'use strict';
  const q=id=>document.getElementById(id);
  function group(id,title,anchor,controls){
    if(q(id))return;
    const nodes=[...new Set(controls.map(control=>control.closest('.field')||control.closest('label')||control))];
    const section=document.createElement('section');section.id=id;section.className='material-section condition-group';
    const heading=document.createElement('h4');heading.id=id+'Title';heading.textContent=title;section.appendChild(heading);
    section.setAttribute('aria-labelledby',heading.id);anchor.before(section);
    for(const node of nodes){
      if(node.classList.contains('field'))section.appendChild(node);
      else{const field=document.createElement('div');field.className='field';section.appendChild(field);field.appendChild(node);}
    }
  }
  group('deckFinishConditions','고정 / 재단 / 발주 조건',document.querySelector('#plannerScreen [data-f]').closest('.field'),[
    document.querySelector('#plannerScreen [data-f]'),q('sawKerf'),q('marginPercent')
  ]);
  group('louverDimensions','시공 치수 / 방향',q('louverLength').closest('.field'),[
    q('louverLength'),q('louverWidth'),document.querySelector('[data-louver-axis]')
  ]);
  group('louverOrderConditions','재단 / 발주 조건',q('louverCalculate'),[q('louverSawKerf'),q('louverMarginPercent')]);
  group('cutProcessingConditions','재단 / 발주 조건',q('cutCalculate'),[q('cutSawKerf'),q('cutMarginPercent')]);
  group('sheetProcessingConditions','재단 / 발주 조건',q('sheetCalculate'),[q('sheetRotate'),q('sheetKerf'),q('sheetMarginPercent')]);
  q('sheetRotate').closest('.field').classList.add('rotation-option');
})();


/* Open a user-controlled printer/PDF dialog. Never submit a job automatically. */
(() => {
  'use strict';
  window.printReport=()=>{
    if(window.MrKimPrintHost===true&&window.chrome?.webview?.postMessage){
      window.chrome.webview.postMessage('mrkim-print-report');return;
    }
    if(window.AndroidPrint?.printDocument){window.AndroidPrint.printDocument();return;}
    window.print();
  };
  window.setupReportPrinting=()=>{
    const buttons=[document.getElementById('printBtn'),document.querySelector('.cut-site-print'),document.getElementById('sheetPrint'),document.getElementById('louverPrint')];
    for(const button of buttons){
      if(!button)continue;button.type='button';button.textContent='프린터 인쇄 / PDF 저장';button.onclick=window.printReport;
      button.title='인쇄 창에서 연결된 프린터 또는 PDF 저장을 선택하세요.';
      if(!button.nextElementSibling?.classList.contains('print-help')){
        const hint=document.createElement('div');hint.className='print-help site-status';
        hint.textContent='인쇄 창의 대상에서 프린터 또는 PDF 저장을 선택하세요. 모바일은 인쇄 서비스가 필요할 수 있습니다.';button.after(hint);
      }
    }
  };
})();


/* Reserve stock is a purchasing allowance, never a change to cut dimensions or drawings. */
(function(root){
 'use strict';
 const percent=value=>{const n=value==null||value===''?0:Number(value);if(!Number.isFinite(n)||n<0||n>100)throw Error('여유율은 0~100% 범위로 입력해주세요.');return n;};
 function counts(base,value){const p=percent(value);if(!Number.isSafeInteger(base)||base<0)throw Error('기본 수량을 확인해주세요.');const extra=Math.ceil(Math.round(base*p*1e8)/1e10),total=base+extra;if(!Number.isSafeInteger(extra)||!Number.isSafeInteger(total))throw Error('발주 수량이 너무 큽니다.');return{base,extra,total};}
 const api={percent,counts,clear:()=>{}};
 if(typeof module!=='undefined'&&module.exports){module.exports=api;return;}
 root.MarginAllowance=api;
 const q=id=>document.getElementById(id),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 for(const [prefix,button]of [['cut','cutCalculate'],['sheet','sheetCalculate'],['louver','louverCalculate']]){
  const box=document.createElement('div');box.className='field';box.innerHTML='<label for="'+prefix+'MarginPercent">여유율 <small>% · 규격별 발주 여유</small></label><input id="'+prefix+'MarginPercent" type="number" min="0" max="100" step="0.1" inputmode="decimal" value="0" placeholder="여유율 %"><div class="site-status">규격별 기본 원자재 수량 × 여유율을 올림해 추가 발주합니다. 재단도면은 기본 수량 기준입니다.</div>';q(button).before(box);
 }
 api.install=()=>{
  const configs=[['deck','marginPercent','calculate','steelCount','deckMaterialQuantities'],['cut','cutMarginPercent','cutCalculate','cutStockCount','cutMaterialQuantities'],['sheet','sheetMarginPercent','sheetCalculate','sheetCount','sheetMaterialQuantities'],['louver','louverMarginPercent','louverCalculate','louverResultCount','louverMaterialQuantities']];
  const panels=new Map();
  for(const [prefix,input,button,total,table]of configs){
   const panel=document.createElement('div');panel.id=prefix+'Allowance';panel.className='procurement-summary';panel.hidden=true;q(total).closest('.card').appendChild(panel);panels.set(prefix,panel);
   const calculate=q(button).onclick;
   q(button).onclick=function(...args){
    panel.replaceChildren();panel.hidden=true;
    let p;try{p=percent(q(input).value);}catch(error){
     if(prefix==='deck')calculate.apply(this,args);
     else if(prefix==='sheet')root.clearSheetResults();
     else if(prefix==='louver')root.clearLouverResults();
     else{for(const id of ['cutStockCount','cutNeedTotal','cutWasteTotal','cutUsage'])q(id).textContent='—';for(const id of ['cutStockSummary','cutMaterialQuantities','cutMaterialLegend','cutTableWrap','standaloneBars'])q(id).innerHTML='';}
     panel.hidden=false;panel.textContent=error.message;return;
    }
    calculate.apply(this,args);
    if(q(total).textContent==='—')return;
    const rows=[...q(table).querySelectorAll('tbody tr')].filter(r=>Number(r.dataset.quantity)>0);
    if(!rows.length)return;
    let sumBase=0,sumExtra=0;
    const body=rows.map(row=>{
     const c=counts(Number(row.dataset.quantity),p),cells=row.children,unit=prefix==='sheet'||prefix==='louver'?'장':'본';sumBase+=c.base;sumExtra+=c.extra;
     return '<tr data-base="'+c.base+'" data-extra="'+c.extra+'" data-total="'+c.total+'"><td>'+esc(cells[1].textContent)+'</td><td>'+esc(cells[2].textContent)+'</td><td>'+c.base+unit+'</td><td>'+c.extra+unit+'</td><td><b>'+c.total+unit+'</b></td></tr>';
    }).join('');
    panel.hidden=false;panel.innerHTML='<h4>여유 포함 발주 수량 · '+p+'%</h4><div class="site-status">기본 '+sumBase+' + 여유 '+sumExtra+' = 발주 '+(sumBase+sumExtra)+' · 여유분은 미재단 원자재로 별도 구매합니다.</div><div class="allowance-table"><table class="cut-table"><thead><tr><th>자재</th><th>규격</th><th>기본</th><th>여유</th><th>발주 합계</th></tr></thead><tbody>'+body+'</tbody></table></div>';
   };
  }
  api.clear=prefix=>{for(const [name,panel]of panels)if(!prefix||prefix===name){panel.hidden=true;panel.replaceChildren();}};
  // Saving or selecting inputs never performs a calculation.
  for(const id of ['stockRows','sheetStockRows','louverStockRows','steelOptions','boardOptions'])q(id)?.closest('.material-section')?.classList.add('stock-input-section');
  for(const id of ['cutRows','sheetItemRows'])q(id)?.closest('.material-section')?.classList.add('item-input-section');
 };
})(typeof window==='undefined'?globalThis:window);

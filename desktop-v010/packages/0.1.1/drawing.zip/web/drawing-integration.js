/* Architecture 0.1.0 — IPedrax/BIMCraft native drawing workspace. */
(()=>{'use strict';
const screen=document.getElementById('drawingScreen'),card=document.getElementById('openDrawing');
if(!screen||!card||!window.PlannerNavigation)return;
const native=!!window.chrome?.webview?.postMessage;
card.querySelector('.module-state').textContent='BIM 설계';
card.querySelector('p').textContent='벽·문·창 편집부터 평면도, 단면도, 3D까지';
screen.className='drawing-module';
screen.innerHTML=`
<header class="drawing-module-header"><div><span class="drawing-eyebrow">ARCHITECTURE / DRAWING</span><h1>건축 도면 설계 <small>0.1.0</small></h1></div><button type="button" data-drawing-home>← 메인화면</button></header>
<div class="drawing-content">
<section class="drawing-intro"><div><span class="drawing-eyebrow">IPedrax / BIMCraft 0.8.0</span><h2>하나의 건물, 연결되는 도면.</h2><p>벽과 공간을 만들고, 평면·단면·3D에서 같은 건물을 편집하세요.</p></div><span class="drawing-offline">● 로컬 작업</span></section>
<nav class="drawing-actions" aria-label="프로젝트 작업">
<button type="button" data-native-action="new"><b>＋ 새 프로젝트</b><span>빈 건물에서 설계 시작</span></button>
<button type="button" data-native-action="open"><b>↗ 도면 파일 열기</b><span>.bimcraft · .ifc</span></button>
<button type="button" data-native-action="sample" class="drawing-primary"><b>샘플 주택 편집하기 →</b><span>작업 사본으로 열기</span></button>
<button type="button" data-native-action="resume" hidden><b>작업 중인 도면으로 →</b><span>열려 있는 편집기 계속 사용</span></button>
</nav><p class="drawing-module-status" role="status" aria-live="polite"></p>
<section class="drawing-example"><div class="drawing-example-heading"><div><span class="drawing-eyebrow">SAMPLE 01</span><h3>단층 주택 <span>10 × 7 m</span></h3></div><div class="drawing-view-tabs" role="tablist" aria-label="샘플 도면 보기"><button type="button" role="tab" aria-selected="true" data-preview="3d">3D 모델</button><button type="button" role="tab" aria-selected="false" data-preview="plan">평면도</button><button type="button" role="tab" aria-selected="false" data-preview="section">단면도</button></div></div>
<div class="drawing-sample-layout"><figure><img id="drawingSampleImage" src="bimcraft-native/previews/house-3d.png" alt="BIMCraft 엔진으로 생성한 샘플 주택의 3D 모델"><figcaption>실제 샘플 모델에서 생성한 미리보기 · 편집은 샘플 주택 편집하기에서</figcaption></figure><aside><span class="drawing-eyebrow">PROJECT NOTES</span><h4>공간을 직접 바꿔보세요.</h4><p>거실, 주방, 침실, 서재를 갖춘 주택입니다. 벽을 선택해 길이와 높이를 바꾸고, 문과 창을 배치할 수 있습니다.</p><dl><div><dt>외곽 중심선</dt><dd>10,000 × 7,000 mm</dd></div><div><dt>공간</dt><dd>4개</dd></div><div><dt>벽 / 문 / 창</dt><dd>7 / 4 / 5개</dd></div><div><dt>출력 시트</dt><dd>평면 · 단면/입면 · 3D</dd></div></dl><a href="bimcraft-native/samples/house.bimcraft" download>샘플 원본 내려받기 ↗</a><a href="bimcraft-native/samples/house.ifc" download>IFC 파일 내려받기 ↗</a><a href="bimcraft-native/samples/house-sheets.pdf" download>도면 PDF 3장 ↗</a></aside></div></section>
<section class="drawing-quick-guide"><div><b>01 · 그리기</b><p>Architecture → Wall / Door / Window</p></div><div><b>02 · 확인하기</b><p>프로젝트 탐색기에서 평면·단면·3D 전환</p></div><div><b>03 · 저장하기</b><p>Ctrl+S 저장 · File → Save As 사본 저장</p></div></section>
<footer class="drawing-footer">설계 엔진: IPedrax/BIMCraft 0.8.0 · MIT / Apache-2.0 <span>편집기 설정 → 사용자 인터페이스 → 언어에서 한국어를 선택할 수 있습니다. 샘플의 BIM 재료는 공통 자재관리에 등록되지 않습니다.</span></footer></div>`;
const status=screen.querySelector('[role=status]');let busy=false,hasSession=false;
function update(){screen.querySelectorAll('[data-native-action]').forEach(b=>{b.disabled=busy;b.hidden=b.dataset.nativeAction==='resume'&&!hasSession;});}
function open(){PlannerNavigation.show('drawingScreen');if(native)window.chrome.webview.postMessage({channel:'architecture-drawing',method:'status'});}
screen.querySelector('[data-drawing-home]').onclick=()=>PlannerNavigation.show('homeScreen');
screen.querySelectorAll('[data-preview]').forEach(button=>button.onclick=()=>{screen.querySelectorAll('[data-preview]').forEach(b=>b.setAttribute('aria-selected',String(b===button)));const names={plan:'평면도','3d':'3D 모델',section:'단면도'},img=screen.querySelector('img');img.src='bimcraft-native/previews/house-'+button.dataset.preview+'.png';img.alt='BIMCraft 엔진으로 생성한 샘플 주택의 '+names[button.dataset.preview];});
screen.querySelectorAll('[data-native-action]').forEach(button=>button.onclick=()=>{
if(!native){status.textContent='편집기는 Windows용 건축설계 프로그램에서 실행됩니다. dist 폴더의 ArchitectureDesign.exe를 열어 주세요. 여기서는 샘플 도면과 파일을 확인할 수 있습니다.';return;}
if(busy)return;busy=true;update();status.textContent='설계 편집기를 준비하고 있습니다…';window.chrome.webview.postMessage({channel:'architecture-drawing',method:button.dataset.nativeAction});
});
if(native)window.chrome.webview.addEventListener('message',event=>{const message=event.data;if(message?.channel!=='architecture-drawing')return;busy=false;if(typeof message.running==='boolean')hasSession=message.running;status.textContent=message.error||message.message||'';update();});
card.onclick=open;window.ArchitectureDrawingIntegration=Object.freeze({open,showHome:()=>PlannerNavigation.show('homeScreen'),showDrawing:open});
})();

(function(){
'use strict';
const MAX_DATA=1500000;
function validate(photo){
 if(photo==null)return;
 if(typeof photo!=='object'||typeof photo.data!=='string'||photo.data.length>MAX_DATA||!/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(photo.data)||typeof photo.name!=='string'||photo.name.length>255)throw Error('제품사진 형식 오류');
}
async function read(file){
 if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('JPG, PNG, WebP 사진을 선택해주세요.');
 if(file.size>10*1024*1024)throw Error('제품사진은 10MB 이하로 선택해주세요.');
 const url=URL.createObjectURL(file),img=new Image();
 try{
  img.src=url;await img.decode();
  if(!img.naturalWidth||!img.naturalHeight||img.naturalWidth*img.naturalHeight>50000000)throw Error('사진 크기가 너무 큽니다. 5천만 화소 이하로 선택해주세요.');
  const scale=Math.min(1,1200/img.naturalWidth,1200/img.naturalHeight),canvas=document.createElement('canvas');
  canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
  const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
  const photo={name:file.name.slice(0,255),data:canvas.toDataURL('image/jpeg',.82)};validate(photo);return photo;
 }finally{URL.revokeObjectURL(url);}
}
function create(after,status){
 let value=null,generation=0,pending=false;
 const box=document.createElement('section');box.className='mat-photo';box.setAttribute('aria-label','제품사진');
 box.innerHTML='<strong>제품사진</strong><div class="mat-photo-preview"><img id="matPhotoPreview" alt="선택한 제품사진" hidden><span id="matPhotoEmpty">등록된 제품사진이 없습니다.</span></div><div class="mat-photo-actions"><button type="button" id="matPhotoChoose">사진 등록 / 변경</button><button type="button" id="matPhotoRemove" disabled>사진 제거</button></div><input id="matPhotoFile" type="file" accept="image/jpeg,image/png,image/webp" hidden><small id="matPhotoName"></small><small>JPG · PNG · WebP / 10MB 이하<br>제품의 모든 규격에서 공유합니다. 등록 / 수정 저장을 누르면 반영됩니다.</small>';
 after.after(box);
 const q=id=>box.querySelector('#'+id),input=q('matPhotoFile');
 function paint(){const img=q('matPhotoPreview');img.hidden=!value;if(value)img.src=value.data;else img.removeAttribute('src');q('matPhotoEmpty').hidden=!!value;q('matPhotoName').textContent=pending?'사진 처리 중…':value?.name||'';q('matPhotoRemove').disabled=!value&&!pending;}
 function set(photo){validate(photo);generation++;pending=false;value=photo?{...photo}:null;input.value='';paint();}
 q('matPhotoChoose').onclick=()=>input.click();
 q('matPhotoRemove').onclick=()=>{set(null);status('사진 제거 예정 · 등록 / 수정 저장을 눌러주세요.');};
 input.onchange=async()=>{const file=input.files[0];if(!file)return;const token=++generation;pending=true;paint();try{const photo=await read(file);if(token!==generation)return;value=photo;status('사진 선택 완료 · 등록 / 수정 저장을 눌러주세요.');}catch(e){if(token===generation)status('사진 등록 실패: '+e.message);}finally{if(token===generation){pending=false;input.value='';paint();}}};
 paint();return {set,get:()=>value?{...value}:null,isPending:()=>pending};
}
window.MaterialPhoto={validate,create};
})();

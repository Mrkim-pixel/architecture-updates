/* Native offline module; reserved for future repository separation. */

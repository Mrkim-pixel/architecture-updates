(function(){
'use strict';
window.MaterialManager={create({button,getData,save,changed}){
 const dialog=document.createElement('dialog');dialog.id='matInfoDialog';dialog.setAttribute('aria-label','상품정보관리');
 dialog.innerHTML='<header><h2>상품정보관리</h2><button type="button" id="matInfoClose">닫기</button></header><p>품명·분류·재질 선택 목록을 관리합니다. 수정하면 사용 중인 상품에도 반영됩니다. 사용 중인 항목은 삭제할 수 없습니다.</p><label>관리 항목 <select id="matInfoKind"><option value="name">품명</option><option value="category">분류</option><option value="material">재질</option></select></label><input id="matInfoSearch" aria-label="기본 상품정보 검색" placeholder="기본 상품정보 검색"><select id="matInfoList" size="9" aria-label="기본 상품정보 목록"></select><label>항목 이름 <input id="matInfoValue" maxlength="200" autocomplete="off"></label><div class="mat-info-actions"><button id="matInfoAdd">추가</button><button id="matInfoEdit">수정</button><button id="matInfoDelete">삭제</button></div><p id="matInfoStatus" role="status"></p>';
 document.body.append(dialog);const q=id=>dialog.querySelector('#'+id);let saving=false;
 function render(value=''){const d=getData(),key=q('matInfoKind').value,term=q('matInfoSearch').value.trim().toLocaleLowerCase();q('matInfoList').replaceChildren(...MaterialOptions.options(d,key).filter(v=>v.toLocaleLowerCase().includes(term)).sort((a,b)=>a.localeCompare(b,'ko',{numeric:true})).map(v=>{const count=d.products.filter(p=>p[key]===v).length;return new Option(v+(count?' · 사용 '+count+'개':''),v);}));q('matInfoList').value=value;sync();}
 function sync(){const selected=!!q('matInfoList').value;for(const id of ['matInfoEdit','matInfoDelete'])q(id).disabled=saving||!selected;q('matInfoAdd').disabled=saving;}
 button.onclick=()=>{render();q('matInfoStatus').textContent='';dialog.showModal();q('matInfoSearch').focus();};q('matInfoClose').onclick=()=>dialog.close();
 q('matInfoKind').onchange=()=>{q('matInfoValue').value='';q('matInfoSearch').value='';render();};q('matInfoSearch').oninput=()=>render();q('matInfoList').onchange=()=>{q('matInfoValue').value=q('matInfoList').value;sync();};
 async function action(mode){if(saving)return;const key=q('matInfoKind').value,old=q('matInfoList').value,value=q('matInfoValue').value.trim();try{
  const d=getData();let next;
  if(mode==='add'){if(MaterialOptions.options(d,key).includes(value))throw Error('이미 등록된 항목입니다.');next=MaterialOptions.add(d,key,value);}
  else{next=MaterialOptions.change(d,key,old,mode==='delete'?null:value);const count=d.products.filter(p=>p[key]===old).length;if(!confirm(mode==='delete'?'선택 목록에서 “'+old+'” 항목을 삭제할까요?':'“'+old+'” → “'+value+'” 수정할까요?\n사용 중인 상품 '+count+'개에 반영됩니다. 기존 현장 스냅샷은 유지됩니다.'))return;}
  saving=true;sync();await save(next);changed(key,old,mode==='delete'?null:value,mode);q('matInfoSearch').value='';render(mode==='delete'?'':value);q('matInfoValue').value=mode==='delete'?'':value;q('matInfoStatus').textContent=({add:'추가',edit:'수정',delete:'삭제'})[mode]+' 완료';
 }catch(e){q('matInfoStatus').textContent=e.message;}finally{saving=false;sync();}}
 for(const [id,mode]of [['matInfoAdd','add'],['matInfoEdit','edit'],['matInfoDelete','delete']])q(id).onclick=()=>action(mode);
}};
})();

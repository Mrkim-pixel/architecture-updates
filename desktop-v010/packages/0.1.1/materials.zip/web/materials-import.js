(function(root){
'use strict';
function merge(current,incoming,validate){
 validate(current);validate(incoming);
 const next=JSON.parse(JSON.stringify(current)),counts={products:0,specs:0,prices:0};
 const occupied=new Map();for(const key of ['products','specs','prices'])for(const row of current[key])occupied.set(row.id,key);
 for(const key of ['products','specs','prices'])for(const row of incoming[key]){
  if(occupied.has(row.id)){if(occupied.get(row.id)!==key)throw Error('기존 ID와 가져올 자료의 종류가 다릅니다.');continue;}
  if(key==='products'&&next.products.some(p=>p.code.toLowerCase()===row.code.toLowerCase()))throw Error('기존 자재코드와 충돌합니다: '+row.code);
  next[key].push(JSON.parse(JSON.stringify(row)));occupied.set(row.id,key);counts[key]++;
 }
 validate(next);return {catalog:next,counts};
}
// Keep merge available for future update checks; no import control or automatic fetch.
root.MaterialCatalogImport={merge};
})(window);

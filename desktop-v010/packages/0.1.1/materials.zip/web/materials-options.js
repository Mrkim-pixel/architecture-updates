/* Project-owned category numbering and reusable field choices. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MaterialOptions=api;})(typeof window==='object'?window:globalThis,function(){
'use strict';
const groups=['철강 / 각관','목재 / 방부목','합판 / MDF','보드 / 내장재','데크 / 합성목재','단열재','마감재 / 몰딩','철물 / 부자재','기타'];
const defaults={name:['각관','아연도 각관','방부목','구조재','방부 데크재','합성목재 WPC','일반합판','방수합판','태고합판','MLH합판','MDF','OSB','일반 석고보드','방수 석고보드','방화 석고보드'],category:groups,material:['아연도금 강재','일반 강재','스테인리스','알루미늄','방부처리 목재','천연목재','목질 합판','목질 MDF','목질 OSB','석고','섬유시멘트','WPC 합성목재','PVC']};
const clone=x=>JSON.parse(JSON.stringify(x)),clean=x=>String(x??'').trim(),unique=a=>[...new Set(a.map(clean).filter(Boolean))];
function category(product){const c=clean(product.category),n=clean(product.name);if(groups.includes(c))return c;
 if(c==='철강 / 각관')return groups[0];if(c==='목재 / 데크')return groups[1];if(c==='판재 / 합판')return groups[2];if(c==='판재 / 내장재')return /MDF|OSB|합판/i.test(n)?groups[2]:groups[3];
 if(c)return c;if(/각관|각파이프|강관|철강/.test(n))return groups[0];if(/합판|MDF|OSB/i.test(n))return groups[2];if(/석고|CRC|보드/i.test(n))return groups[3];if(/합성|WPC/i.test(n))return groups[4];if(/목재|방부|구조재|데크/.test(n))return groups[1];return groups[8];}
function validate(settings){if(settings===undefined)return;if(!settings||settings.materialOptionsVersion!==1||!Array.isArray(settings.codeGroups)||!settings.choices)throw Error('자재 선택 목록 설정 형식 오류');if(settings.hiddenChoices)for(const k of ['name','category','material'])if(!Array.isArray(settings.hiddenChoices[k])||settings.hiddenChoices[k].some(v=>typeof v!=='string'||!v.trim()||v.length>200))throw Error('숨김 선택 목록 형식 오류');const names=new Set(),bases=new Set();for(const g of settings.codeGroups){if(!clean(g.name)||names.has(g.name)||!Number.isSafeInteger(g.base)||g.base<1000||g.base%1000||bases.has(g.base)||!Number.isSafeInteger(g.next)||g.next<g.base+1||g.next>g.base+1000)throw Error('분류 코드 번호대 형식 오류');names.add(g.name);bases.add(g.base);}for(const k of ['name','category','material'])if(!Array.isArray(settings.choices[k])||settings.choices[k].some(v=>typeof v!=='string'||!v.trim()||v.length>200))throw Error('선택 목록 값 형식 오류');}
function prepare(catalog){const d=clone(catalog);validate(d.settings);if(!d.settings)d.settings={materialOptionsVersion:1,codeGroups:groups.map((name,i)=>({name,base:(i+1)*1000,next:(i+1)*1000+1})),choices:{name:[],category:[],material:[]}};
 const settings=d.settings;for(const name of groups)if(!settings.codeGroups.some(g=>g.name===name)){const base=(groups.indexOf(name)+1)*1000;if(settings.codeGroups.some(g=>g.base===base))continue;settings.codeGroups.push({name,base,next:base+1});}
 for(const p of d.products)p.category=category(p);
 for(const name of unique([...settings.choices.category,...d.products.map(p=>p.category)])){if(!settings.codeGroups.some(g=>g.name===name)){const base=Math.max(9000,...settings.codeGroups.map(g=>g.base))+1000;settings.codeGroups.push({name,base,next:base+1});}}
 const used=new Set();const sorted=[...d.products].sort((a,b)=>String(a.code).localeCompare(String(b.code),'ko',{numeric:true})||String(a.id).localeCompare(String(b.id)));
 for(const p of sorted){const g=settings.codeGroups.find(g=>g.name===p.category),num=Number(p.code);if(/^\d+$/.test(String(p.code))&&num>g.base&&num<g.base+1000&&!used.has(String(num))){p.code=String(num);used.add(p.code);g.next=Math.max(g.next,num+1);}else{if(clean(p.code))p.previousCodes=unique([...(p.previousCodes||[]),p.code]);p.code='';}}
 for(const p of sorted.filter(p=>!p.code)){const g=settings.codeGroups.find(g=>g.name===p.category);while(used.has(String(g.next)))g.next++;if(g.next>=g.base+1000)throw Error(p.category+' 분류의 코드 번호가 모두 사용되었습니다. 새 분류를 추가해주세요.');p.code=String(g.next++);used.add(p.code);}
 for(const k of ['name','category','material'])settings.choices[k]=unique([...settings.choices[k],...d.products.map(p=>p[k])]);validate(settings);return d;}
function options(catalog,key){return unique([...(catalog.settings?.choices[key]||[]),...catalog.products.map(p=>p[key]),...(defaults[key]||[])]).filter(v=>!(catalog.settings?.hiddenChoices?.[key]||[]).includes(v));}
function add(catalog,key,value){value=clean(value);if(!['name','category','material'].includes(key)||!value||value.length>200)throw Error('1~200자의 선택값을 입력해주세요.');const d=prepare(catalog);if(d.settings.hiddenChoices?.[key])d.settings.hiddenChoices[key]=d.settings.hiddenChoices[key].filter(v=>v!==value);d.settings.choices[key]=unique([...d.settings.choices[key],value]);return prepare(d);}
function change(catalog,key,oldValue,newValue){
 if(!['name','category','material'].includes(key)||!options(catalog,key).includes(oldValue))throw Error('관리할 항목을 선택해주세요.');
 const d=prepare(catalog),used=d.products.filter(p=>p[key]===oldValue);
 if(newValue===null&&used.length)throw Error('등록 상품 '+used.length+'개에서 사용 중입니다. 상품 값을 변경한 후 삭제해주세요.');
 if(newValue!==null){newValue=clean(newValue);if(!newValue||newValue.length>200)throw Error('1~200자로 입력해주세요.');if(newValue===oldValue)return d;if(options(d,key).includes(newValue))throw Error('이미 등록된 항목입니다.');}
 d.settings.hiddenChoices??={name:[],category:[],material:[]};d.settings.hiddenChoices[key]=unique([...(d.settings.hiddenChoices[key]||[]),oldValue]);
 d.settings.choices[key]=d.settings.choices[key].filter(v=>v!==oldValue);
 if(newValue!==null){d.settings.hiddenChoices[key]=d.settings.hiddenChoices[key].filter(v=>v!==newValue);d.settings.choices[key].push(newValue);for(const p of used)p[key]=newValue;
 if(key==='category'){const g=d.settings.codeGroups.find(g=>g.name===oldValue);if(g){if(d.settings.codeGroups.some(x=>x!==g&&x.name===newValue))throw Error('이전에 사용한 분류명입니다. 다른 이름을 입력해주세요.');g.name=newValue;}}}
 return prepare(d);
}
function preview(catalog,product){const d=clone(catalog);const index=d.products.findIndex(p=>p.id===product.id);if(index<0)d.products.push({...product,id:'code-preview',code:''});else d.products[index]={...d.products[index],...product};const prepared=prepare(d),p=prepared.products.find(p=>p.id===(index<0?'code-preview':product.id));return {code:p.code,category:p.category,group:prepared.settings.codeGroups.find(g=>g.name===p.category)};}
return {prepare,validate,options,add,change,preview,category,groups};
});

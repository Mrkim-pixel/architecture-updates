/* Project-owned offline IndexedDB repository. No external dependencies. */
(function(root){
'use strict';
const NAME='architecture-materials-v010',VERSION=1,TABLES=['products','specs','prices'];
const clone=x=>JSON.parse(JSON.stringify(x));
const request=r=>new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
const complete=t=>new Promise((resolve,reject)=>{t.oncomplete=resolve;t.onabort=()=>reject(t.error||Error('데이터베이스 트랜잭션이 취소되었습니다.'));t.onerror=()=>{};});
async function open(validate,legacyStorage=root.localStorage){
 if(!root.indexedDB)throw Error('이 환경에서 로컬 데이터베이스를 사용할 수 없습니다.');
 const opening=root.indexedDB.open(NAME,VERSION);
 opening.onupgradeneeded=()=>{
  const db=opening.result;
  const products=db.createObjectStore('products',{keyPath:'id'});products.createIndex('code','code',{unique:true});products.createIndex('name','name');
  const specs=db.createObjectStore('specs',{keyPath:'id'});specs.createIndex('productId','productId');
  const prices=db.createObjectStore('prices',{keyPath:'id'});prices.createIndex('specId','specId');prices.createIndex('supplier','supplier');prices.createIndex('date','date');
  db.createObjectStore('meta',{keyPath:'key'});
 };
 opening.onblocked=()=>{root.dispatchEvent(new CustomEvent('catalog-database-blocked'));};
 const db=await request(opening);db.onversionchange=()=>db.close();
 async function read(){
  const tx=db.transaction([...TABLES,'meta'],'readonly'),done=complete(tx);
  const all=TABLES.map(k=>request(tx.objectStore(k).getAll()));
  const state=request(tx.objectStore('meta').get('state'));const settings=request(tx.objectStore('meta').get('catalogSettings'));
  const [rows,meta,config]=await Promise.all([Promise.all(all),state,settings]);await done;
  return {catalog:validate({schema:1,...Object.fromEntries(TABLES.map((k,i)=>[k,rows[i]])),...(config?{settings:config.value}:{})}),revision:meta?.revision||0,initialized:!!meta};
 }
 async function write(catalog,revision,{recover=false,migrate=false,legacyPrevious=null}={}){
  validate(catalog);
  const tx=db.transaction([...TABLES,'meta'],'readwrite'),done=complete(tx);let failure;
  const meta=tx.objectStore('meta'),state=meta.get('state');
  state.onsuccess=()=>{
   try{
    const current=state.result;
    if((current?.revision||0)!==revision)throw Error('다른 창에서 자재가 변경되었습니다. 최신 목록을 확인한 후 다시 저장하세요.');
    // Queue the complete old ledger before replacing any row. All stores commit together.
    const rows=TABLES.map(k=>({key:k,req:tx.objectStore(k).getAll()}));rows.push({key:'settings',req:meta.get('catalogSettings')});let remaining=rows.length;
    for(const row of rows)row.req.onsuccess=()=>{if(--remaining)return;try{
     if(current){meta.put({key:'previous',catalog:{schema:1,...Object.fromEntries(rows.filter(r=>r.key!=='settings').map(r=>[r.key,r.req.result])),...(rows[3].req.result?{settings:rows[3].req.result.value}:{})}});}
     else if(legacyPrevious)meta.put({key:'previous',catalog:validate(legacyPrevious)});
     if(catalog.settings)meta.put({key:'catalogSettings',value:clone(catalog.settings)});else meta.delete('catalogSettings');
     for(const k of TABLES){const table=tx.objectStore(k);table.clear();for(const item of catalog[k])table.put(clone(item));}
     meta.put({key:'state',revision:revision+1,updatedAt:new Date().toISOString(),migratedFromLocalStorage:migrate||current?.migratedFromLocalStorage||false});
    }catch(e){failure=e;tx.abort();}};
   }catch(e){failure=e;tx.abort();}
  };
  try{await done;}catch(e){throw failure||e;}return revision+1;
 }
 async function initialize(){
  let result=await read();if(result.initialized)return result;
  const raw=legacyStorage.getItem(NAME),previous=legacyStorage.getItem(NAME+'-previous');
  const catalog=raw?validate(JSON.parse(raw)):{schema:1,products:[],specs:[],prices:[]};let old=null;
  if(previous){try{old=validate(JSON.parse(previous));}catch(_){} }
  try{await write(catalog,0,{migrate:!!raw,legacyPrevious:old});}catch(e){const other=await read();if(!other.initialized)throw e;}
  return read(); // Legacy entries are retained untouched as migration recovery copies.
 }
 async function previous(){const tx=db.transaction('meta','readonly'),done=complete(tx);const value=await request(tx.objectStore('meta').get('previous'));await done;if(!value)throw Error('이전 저장본이 없습니다.');return clone(validate(value.catalog));}
 return {read,write,initialize,previous,close:()=>db.close(),name:NAME,version:VERSION};
}
root.MaterialDatabase={open,name:NAME,version:VERSION};
})(window);

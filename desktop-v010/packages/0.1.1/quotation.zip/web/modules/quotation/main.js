/* Separately replaceable quotation module entry. No quote data is seeded. */
window.ArchitectureQuotation={version:'0.1.0',available:false};
